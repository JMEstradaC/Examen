import { axiosSingleton } from '../plugins/axios'

const producto = "Productos"
const insumo = "Insumos"
const categoria = "Categorias"

//Icons
export function getListIcons() {
    return axiosSingleton.getInstance().get(`/ImagenIcons`)
}

// Productos
export function getListProducto() {
    return axiosSingleton.getInstance().get(`/${producto}`)
}

export function postProducto(item) {
    return axiosSingleton.getInstance().post(`/${producto}`, item)
}

export function putProducto(id, item) {
    return axiosSingleton.getInstance().put(`/${producto}/${id}`, item)
}

export function deleteProducto(id) {
    return axiosSingleton.getInstance().delete(`/${producto}/${id}`)
}

// Insumos
export function getListInsumo() {
    return axiosSingleton.getInstance().get(`/${insumo}`)
}

export function postInsumo(item) {
    return axiosSingleton.getInstance().post(`/${insumo}`, item)
}

export function putInsumo(id, item) {
    return axiosSingleton.getInstance().put(`/${insumo}/${id}`, item)
}

export function deleteInsumo(id) {
    return axiosSingleton.getInstance().delete(`/${insumo}/${id}`)
}

// Categorías
export function getListCategorias() {
    return axiosSingleton.getInstance().get(`/${categoria}`)
}

export function postCategoria(item) {
    return axiosSingleton.getInstance().post(`/${categoria}`, item)
}

export function putCategoria(id, item) {
    return axiosSingleton.getInstance().put(`/${categoria}/${id}`, item)
}

export function deleteCategoria(id) {
    return axiosSingleton.getInstance().delete(`/${categoria}/${id}`)
}