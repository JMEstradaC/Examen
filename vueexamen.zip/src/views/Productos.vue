<template>
    <v-container fluid>
        <v-row>
            <v-col
                cols="12"
                md="12"
            >
                <material-card
                    color="accent"
                    full-header
                >
                    <template #heading>
                        <v-tabs
                            v-model="tabs"
                            background-color="transparent"
                            slider-color="white"
                            class="pa-8"
                        >
                            <v-tab class="mr-3">
                                <v-icon class="mr-2">
                                    mdi-ice-cream
                                </v-icon>
                                Productos
                            </v-tab>
                            <v-tab class="mr-3">
                                <v-icon class="mr-2">
                                    mdi-food-fork-drink
                                </v-icon>
                                Insumos
                            </v-tab>
                            <v-tab class="mr-3">
                                <v-icon class="mr-2">
                                    mdi-duck
                                </v-icon>
                                Categorías
                            </v-tab>
                        </v-tabs>
                    </template>
                    <v-tabs-items
                        v-model="tabs"
                        background-color="transparent"
                    >
                        <v-tab-item key="0">
                            <v-card-text>
                                <table-component
                                    title-table="Agregar producto"
                                    :headers="hProductos"
                                    :items-table="listProductos"
                                    :is-crud="true"
                                    @open-form="agregarP"
                                    @item-edit="actualizarP"
                                    @item-delete="eliminarP"
                                />
                            </v-card-text>

                            <!-- <v-card-text>
                <material-card
                  icon="mdi-clipboard-text"
                  icon-small
                  title="Simple Table"
                  color="accent"
                >

                </material-card>
              </v-card-text> -->
                        </v-tab-item>
                        <v-tab-item key="1">
                            <v-card-text>
                                <table-component
                                    title-table="Agregar insumo"
                                    :headers="hInsumos"
                                    :items-table="listInsumos"
                                    :is-crud="true"
                                    @open-form="agregarI"
                                    @item-edit="actualizarI"
                                    @item-delete="eliminarI"
                                />
                            </v-card-text>
                        </v-tab-item>
                        <v-tab-item key="2">
                            <v-card-text>
                                <table-component
                                    title-table="Agregar categoría"
                                    :headers="hCategoria"
                                    :items-table="listCategorias"
                                    :is-crud="true"
                                    @open-form="agregarC"
                                    @item-edit="actualizarC"
                                    @item-delete="eliminarC"
                                />
                            </v-card-text>
                        </v-tab-item>
                    </v-tabs-items>
                </material-card>
            </v-col>
        </v-row>
        <categoria-form
            :show-dialog="dialogC"
            :obj-categoria="itemCategoria"
            :is-update="isUpdateC"
            @close-form="salirDialogC"
            @refresh-table="getCategorias"
        />
    </v-container>
</template>

<script>
  import TableComponent from '../components/generic/TableComponent.vue'
  import {
    getListProducto,
    deleteProducto,
    getListInsumo,
    deleteInsumo,
    getListCategorias,
    deleteCategoria,
  } from '@/api/productosApi'
  import CategoriaForm from '../components/forms/CategoriaForm.vue'
  export default {
    name: 'ProductosView',
    components: {
      TableComponent,
      CategoriaForm,
    },
    data() {
      return {
        tabs: 0,
        dialogC: false,
        dialogI: false,
        dialogP: false,
        isConsultaC: true,
        isUpdateC: false,
        isConsultaI: true,
        isUpdateI: false,
        isConsultaP: true,
        isUpdateP: false,
        listProductos: [],
        listInsumos: [],
        listCategorias: [],
        itemProducto: {},
        itemInsumo: {},
        itemCategoria: {},
        hProductos: [
          {
            text: 'Código',
            value: 'codigoReferencia',
          },
          {
            text: 'Nombre',
            value: 'nombre',
          },
          {
            text: 'Admin',
            value: 'acciones',
          },
        ],
        hInsumos: [
          {
            text: 'Código',
            value: 'codigoReferencia',
          },
          {
            text: 'Nombre',
            value: 'nombre',
          },
          {
            text: 'Admin',
            value: 'acciones',
          },
        ],
        hCategoria: [
          {
            text: 'Nombre',
            value: 'nombre',
          },
          {
            text: 'Admin',
            value: 'acciones',
          },
        ],
      }
    },
    mounted() {
      this.getProductos()
      this.getInsumos()
      this.getCategorias()
    },
    methods: {
      async getProductos() {
        var self = this
        try {
          const response = await getListProducto()
          var items = response.data
          self.listProductos = items
        } catch (e) {
          console.log(e)
          this.$swal({
          title: "Error",
          text: e.toString(),
          icon: "error",
          confirmButtonText: "Aceptar",
        });
        }
      },
      async getInsumos(){
        var self = this
        try{
          const res = await getListInsumo()
          var its = res.data
           self.listInsumos = its
        }catch (e) {
          console.log(e)
          this.$swal({
          title: "Error",
          text: e.toString(),
          icon: "error",
          confirmButtonText: "Aceptar",
        });
        }

      },
      async getCategorias(){
         var self = this
        try{
          const resc = await getListCategorias()
          var itsc = resc.data

          self.listCategorias = itsc
        }catch (e) {
          console.log(e)
          this.$swal({
          title: "Error",
          text: e.toString(),
          icon: "error",
          confirmButtonText: "Aceptar",
        });
        }

      },
      agregarP() {
        this.dialogP = true
        this.isConsultaP = false
        this.itemProducto = {}
      },
      consultarP(item) {
        this.dialogP = true
        this.isConsultaP = true
        this.objPeriodo = item
      },
      actualizarP(item) {
        this.dialogP = true
        this.isUpdateP = true
        this.itemProducto = item
      },
      async eliminarP(item) {
        const response = await deleteProducto(item.idProducto)

        if (response.status === 204 || response.status === 200) {
          const index = this.listProductos.indexOf(item)
          this.listProductos.splice(index, 1)
        } else {
          this.tipoMsj = 2
          this.msjDialog = response.status
        }
      },
      agregarI() {
        this.dialogI = true
        this.isConsultaI = false
        this.itemInsumo = {}
      },
      consultarI(item) {
        this.dialogI = true
        this.isConsultaI = true
        this.itemInsumo = item
      },
      actualizarI(item) {
        this.dialogI = true
        this.isUpdate = true
        this.itemInsumo = item
      },
      async eliminarI(item) {
        const response = await deleteInsumo(item.idInsumo)

        if (response.status === 204 || response.status === 200) {
          const index = this.listInsumos.indexOf(item)
          this.listInsumos.splice(index, 1)
        } else {
          this.tipoMsj = 2
          this.msjDialog = response.status
        }
      },
      agregarC() {
        this.dialogC = true
        this.isConsultaC = false
        this.itemCategoria = {}
      },
      consultarC(item) {
        this.dialogC = true
        this.isConsultaC = true
        this.itemCategoria = item
      },
      actualizarC(item) {
        this.dialogC = true
        this.isUpdateC = true
        this.itemCategoria = item
      },
      async eliminarC(item) {
        const response = await deleteCategoria(item.idCategoria)

        if (response.status === 204 || response.status === 200) {
          const index = this.listCategorias.indexOf(item)
          this.listCategorias.splice(index, 1)
        } else {
          this.tipoMsj = 2
          this.msjDialog = response.status
        }
      },
      salirDialogC(show) {
      this.dialogC = show;
    },

    },
  }
</script>

<style lang="scss" scoped></style>
