<template>
  <v-container id="Pedidos-View" fluid tag="pedidos">
    <v-row>
      <v-col cols="12" md="6">
        <material-card color="#5DC1B9" full-header>
          <template #heading>
            <v-tabs
              v-model="tabs"
              background-color="transparent"
              slider-color="white"
              class="pa-8"
            >
              <!-- <span
                                class="subheading font-weight-light mx-3"
                                style="align-self: center"
                            >Tasks:</span> -->

              <v-tab class="mr-3">
                <v-icon class="mr-2"> mdi-ice </v-icon>
                Categorias
              </v-tab>
              <v-tab class="mr-3">
                <v-icon class="mr-2"> mdi-ice-cream </v-icon>
                Sabor
              </v-tab>
              <v-tab class="mr-3">
                <v-icon class="mr-2"> cookie-plus </v-icon>
                toppings
              </v-tab>
              <v-tab>
                <v-icon class="mr-2"> mdi-water-plus </v-icon>
                Extra
              </v-tab>
            </v-tabs>
          </template>
          <v-tabs-items v-model="tabs" background-color="transparent">
              <!-- item Categorias -->
            <v-tab-item >
              <v-card-text>
                <template>
                  <v-list shaped>
                    <v-list-item-group v-model="model" multiple>
                      <template v-for="(item, i) in listCategorias">
                        <v-divider
                          v-if="!item"
                          :key="`divider-${i}`"
                        ></v-divider>

                        <v-list-item
                          v-else
                          :key="`item-${i}`"
                          :value="item"
                          active-class="deep-purple--text text--accent-4"
                        >
                          <template v-slot:default="{ active }">
                            <v-list-item-content>
                              <v-list-item-title
                                v-text="item.nombre"
                              ></v-list-item-title>
                            </v-list-item-content>

                            <v-list-item-action>
                              <v-checkbox
                                :input-value="active"
                                color="deep-purple accent-4"
                              ></v-checkbox>
                            </v-list-item-action>
                          </template>
                        </v-list-item>
                      </template>
                    </v-list-item-group>
                  </v-list>
                </template>
              </v-card-text>
            </v-tab-item>
            <!-- tab 2 -->
              <v-tab-item >
              <v-card-text>
                <template>
                  <v-list shaped>
                    <v-list-item-group v-model="model" multiple>
                      <template v-for="(item, i) in items">
                        <v-divider
                          v-if="!item"
                          :key="`divider-${i}`"
                        ></v-divider>

                        <v-list-item
                          v-else
                          :key="`item-${i}`"
                          :value="item"
                          active-class="deep-purple--text text--accent-4"
                        >
                          <template v-slot:default="{ active }">
                            <v-list-item-content>
                              <v-list-item-title
                                v-text="item"
                              ></v-list-item-title>
                            </v-list-item-content>

                            <v-list-item-action>
                              <v-checkbox
                                :input-value="active"
                                color="deep-purple accent-4"
                              ></v-checkbox>
                            </v-list-item-action>
                          </template>
                        </v-list-item>
                      </template>
                    </v-list-item-group>
                  </v-list>
                </template>
              </v-card-text>
            </v-tab-item>
          </v-tabs-items>
        </material-card>
      </v-col>
      <v-col cols="12" md="6">
        <v-card-title class="indigo white--text text-h5">
          User Directory Chia
        </v-card-title>
        <material-card color="#5DC1B9" full-header>
          <v-container>
            <v-select
              v-model="selectionType"
              :items="['leaf', 'independent']"
              label="Selection type"
            />
            <v-row>
              <v-col>
                <v-treeview
                  v-model="selection"
                  :items="items"
                  :selection-type="selectionType"
                  selectable
                  return-object
                  open-all
                />
              </v-col>
              <v-divider vertical />
              <v-col class="pa-6" cols="6">
                <template v-if="!selection.length">
                  No nodes selected.
                </template>
                <template v-else>
                  <div v-for="node in selection" :key="node.id">
                    {{ node.name }}
                  </div>
                </template>
              </v-col>
            </v-row>
          </v-container>
        </material-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
// Utilities
import {
  getListProducto,
  deleteProducto,
  getListInsumo,
  deleteInsumo,
  getListCategorias,
  deleteCategoria,
} from "@/api/productosApi";

export default {
  name: "PedidosView",
  data: () => ({
    tabs: 0,
    listCategorias: [],
    items: ["Dog Photos", "Cat Photos", "", "Potatoes", "Carrots"],
    model: ["Carrots"],
    tasks: {
      
    },
    selectionType: "leaf",
    selection: [],
    //   items: [
    //     {
    //       id: 1,
    //       name: 'sabores',
    //       children: [
    //         { id: 2, name: 'Chocolate' },
    //         { id: 3, name: 'Fresa' },
    //         {
    //           id: 4,
    //           name: 'toppings',
    //           children: [
    //             { id: 5, name: 'Chocolate' },
    //             { id: 6, name: 'Ferrero ' },
    //           ],
    //         },
    //       ],
    //     },
    //   ],
  }),

  mounted() {
    this.getProductos();
  },
  methods: {
    async getProductos() {
      var self = this;
      try {
        const response = await getListProducto();
        var items = response.data;

        const res = await getListInsumo();
        var its = res.data;

        const resc = await getListCategorias();
        var itsc = resc.data;

        self.listProductos = items;

        self.listInsumos = its;

        self.listCategorias = itsc;
        console.log("llega");
        console.log("categorias", self.listCategorias);
      } catch (e) {
        console.log(e);
        // this.tipoMsj = 2;
        // this.msjDialog = "Error";
      }
    },
    agregarP() {
      this.dialogP = true;
      this.isConsultaP = false;
      this.itemProducto = {};
    },
    consultarP(item) {
      this.dialogP = true;
      this.isConsultaP = true;
      this.objPeriodo = item;
    },
    actualizarP(item) {
      this.dialogP = true;
      this.isUpdateP = true;
      this.itemProducto = item;
    },
    async eliminarP(item) {
      const response = await deleteProducto(item.idProducto);

      if (response.status === 204 || response.status === 200) {
        const index = this.listProductos.indexOf(item);
        this.listProductos.splice(index, 1);
      } else {
        this.tipoMsj = 2;
        this.msjDialog = response.status;
      }
    },
    agregarI() {
      this.dialogI = true;
      this.isConsultaI = false;
      this.itemInsumo = {};
    },
    consultarI(item) {
      this.dialogI = true;
      this.isConsultaI = true;
      this.itemInsumo = item;
    },
    actualizarI(item) {
      this.dialogI = true;
      this.isUpdate = true;
      this.itemInsumo = item;
    },
    async eliminarI(item) {
      const response = await deleteInsumo(item.idInsumo);

      if (response.status === 204 || response.status === 200) {
        const index = this.listInsumos.indexOf(item);
        this.listInsumos.splice(index, 1);
      } else {
        this.tipoMsj = 2;
        this.msjDialog = response.status;
      }
    },
    agregarC() {
      this.dialogC = true;
      this.isConsultaC = false;
      this.itemCategoria = {};
    },
    consultarC(item) {
      this.dialogC = true;
      this.isConsultaC = true;
      this.itemCategoria = item;
    },
    actualizarC(item) {
      this.dialogC = true;
      this.isUpdateC = true;
      this.itemCategoria = item;
    },
    async eliminarC(item) {
      const response = await deleteCategoria(item.idCategoria);

      if (response.status === 204 || response.status === 200) {
        const index = this.listCategorias.indexOf(item);
        this.listCategorias.splice(index, 1);
      } else {
        this.tipoMsj = 2;
        this.msjDialog = response.status;
      }
    },
    salirDialogC(show) {
      this.dialogC = show;
    },
  },
};
</script>
