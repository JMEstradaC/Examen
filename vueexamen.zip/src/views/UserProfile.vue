<template>
    <v-container
        id="user-profile-view"
        fluid
        tag="section"
    >
        <v-row justify="center">
            <v-col
                cols="12"
                md="8"
            >
                <material-card
                    color="primary"
                    icon="mdi-account-outline"
                >
                    <template #title>
                        Editar Pefil — <small class="text-body-1">Completa tu perfil</small>
                    </template>
                    <v-form>
                        <v-container class="py-0">
                            <v-row>
                                <v-col
                                    cols="12"
                                    md="4"
                                >
                                    <v-text-field label="Sucursal" />
                                </v-col>

                                <v-col
                                    cols="12"
                                    md="4"
                                >
                                    <v-text-field
                                        color="purple"
                                        label="Nombre de usuario"
                                    />
                                </v-col>

                                <v-col
                                    cols="12"
                                    md="4"
                                >
                                    <v-text-field
                                        color="purple"
                                        label="Correo electronico"
                                    />
                                </v-col>

                                <v-col
                                    cols="12"
                                    md="6"
                                >
                                    <v-text-field
                                        color="purple"
                                        label="Nombres"
                                    />
                                </v-col>

                                <v-col
                                    cols="12"
                                    md="6"
                                >
                                    <v-text-field
                                        color="purple"
                                        label="Apellidos"
                                    />
                                </v-col>

                                <v-col cols="12">
                                    <v-text-field
                                        color="purple"
                                        label="Direccion"
                                    />
                                </v-col>

                                <v-col
                                    cols="12"
                                    md="4"
                                >
                                    <v-text-field
                                        color="purple"
                                        label="Ciudad"
                                    />
                                </v-col>

                                <v-col
                                    cols="12"
                                    md="4"
                                >
                                    <v-text-field
                                        color="purple"
                                        label="Pais"
                                    />
                                </v-col>

                                <v-col
                                    cols="12"
                                    md="4"
                                >
                                    <v-text-field
                                        color="purple"
                                        label="Codigo postal"
                                        type="number"
                                    />
                                </v-col>

                                <v-col cols="12">
                                    <v-textarea
                                        color="purple"
                                        label="Observaciones"
                                    />
                                </v-col>

                                <v-col
                                    cols="12"
                                    class="text-right"
                                >
                                    <v-btn
                                        color="primary"
                                        min-width="150"
                                    >
                                        Actualizar perfil
                                    </v-btn>
                                </v-col>
                            </v-row>
                        </v-container>
                    </v-form>
                </material-card>
            </v-col>

            <!-- <v-col
        cols="12"
        md="4"
      >
        <app-card class="mt-4 text-center">
          <v-img
            class="rounded-circle elevation-6 mt-n12 d-inline-block"
            src="https://demos.creative-tim.com/vue-material-dashboard/img/marc.aba54d65.jpg"
            width="128"
          />

          <v-card-text class="text-center">
            <h6 class="text-h6 mb-2 text--secondary">
              CEO / FOUNDER
            </h6>

            <h4 class="text-h4 mb-3 text--primary">
              John Leider
            </h4>

            <p class="text--secondary">
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ratione dolorem deserunt veniam tempora magnam quisquam quam error iusto cupiditate ducimus, et eligendi saepe voluptatibus assumenda similique temporibus placeat animi dicta?
            </p>

            <v-btn
              class="mr-0"
              color="primary"
              min-width="100"
              rounded
            >
              Follow
            </v-btn>
          </v-card-text>
        </app-card>
      </v-col> -->
        </v-row>
    </v-container>
</template>

<script>
  export default { name: 'UserProfileView' }
</script>
