<template>
    <div />
</template>

<script>
  export default {
    name: 'InsumoForm',
    data() {
      return {
        key: value,
      }
    },
    methods: {
      name() {},
    },
  }
</script>

<style lang="scss" scoped></style>
