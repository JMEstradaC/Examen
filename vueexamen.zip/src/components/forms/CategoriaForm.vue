<template>
    <v-dialog
        v-model="dialog"
        persistent
        max-width="400px"
    >
        <v-form
            ref="form"
            v-model="valid"
            lazy-validation
            @submit.prevent="guardar"
        >
            <v-card>
                <v-card-title>
                    <span
                        v-if="!isUpdate"
                        class="headline"
                    >Agregar categoría</span>
                    <span
                        v-else
                        class="headline"
                    >Actualizar categoría</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-text-field
                            v-model="dataCategoria.nombre"
                            :counter="15"
                            :rules="[v => !!v || 'Nombre de categoría requerido']"
                            label="Nombre"
                            required
                        />

                        <v-autocomplete
                            v-model="imgIcon"
                            :items="items"
                            color="blue-grey lighten-2"
                            label="Seleccionar"
                            item-text="nombreImagen"
                            item-value="idImagen"
                            cache-items
                            flat
                            hide-details
                            @change="selectIcon()"
                        >
                            <template v-slot:no-data>
                                <v-list-item>
                                    <v-list-item-title>
                                        Sin resultados
                                    </v-list-item-title>
                                </v-list-item>
                            </template>
                            <template v-slot:selection="{ attr, on, item, selected }">

                                    <v-avatar left>
                                        <v-img :src="require('@/assets/png_elate/'+item.nombreImagen+'.png')" />
                                    </v-avatar>

                                <span v-text="item.nombreImagen" />
                            </template>
                            <template v-slot:item="{ item }">
                                <v-list-item-avatar>
                                    <v-img :src="require('@/assets/png_elate/'+item.nombreImagen+'.png')" />
                                </v-list-item-avatar>
                                <v-list-item-content>
                                    <v-list-item-title v-text="item.nombreImagen" />
                                </v-list-item-content>
                            </template>
                        </v-autocomplete>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer />
                    <v-btn
                        color="success"
                        class="mr-4"
                        type="submit"
                    >
                        Guardar
                    </v-btn>

                    <v-btn
                        color="error"
                        class="mr-4"
                        @click="salirDialog"
                    >
                        Cancelar
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-form>
    </v-dialog>
</template>

<script>
  import { getListIcons,putCategoria,postCategoria } from '@/api/productosApi'

  export default {
    name: 'CategoriaForm',
    props: {
      showDialog: {
        type: Boolean,
        required: true,
      },
      objCategoria: {
        type: Object,
        required: true,
      },
      isUpdate: {
        type: Boolean,
        required: false,
        default: false,
      },
    },
    data() {
      return {
        dialog: false,
        valid: true,
        name: null,
        items: null,
        imgIcon: null,
        dataCategoria: {
          idCategoria: 0,
          idImagen: 0,
          nombre: '',
          color: '',
          viejoId: 0,
        },
      }
    },
    watch: {
      showDialog: {
        immediate: true,
        deep: true,
        handler(newValue, oldValue) {
          this.dialog = newValue
        },
      },
      objCategoria: {
        immediate: true,
        deep: true,
        handler(newValue, oldValue) {
          if (this.isUpdate) {
            this.dataCategoria = newValue
            this.imgIcon = newValue.idImagen
            this.dataCategoria.nombre = newValue.nombre
          }else{
            this.dataCategoria = {}
            this.imgIcon = null
          }
        },
      },
    },
    mounted() {
      // this.$refs.form.reset();
      this.getIcons()
    },
    methods: {
      salirDialog() {
        //this.reset()
        this.$emit('close-form', false)
      },
      async getIcons() {
        try {
          const response = await getListIcons()
          this.items = response.data
        } catch (e) {
          this.$swal({
            title: 'Error',
            text: e.toString(),
            icon: 'error',
            confirmButtonText: 'Aceptar',
          })
        }
      },
      selectIcon() {
        if (this.imgIcon) {
          // console.log(this.imgIcon)
          // var icon = this.items.filter(e => {
          //   return (
          //     (e.idImagen || '')
          //       .toLowerCase()
          //       .indexOf((this.imgIcon || '').toLowerCase()) > -1
          //   )
          // })[0]

          this.dataCategoria.idImagen = this.imgIcon
        }
      },
      validarForm() {
        return this.$refs.form.validate()
      },
      reset() {
       this.$refs.form.reset()
      },
      async guardar(){

        if(this.validarForm()){

          if(this.isUpdate){

            let response = await putCategoria(
              this.dataCategoria.idCategoria,
              this.dataCategoria
            );
            if (response.status === 204) {
              this.$swal({
                title: "Actualizado correctamente",
                icon: "success",
                confirmButtonText: "Aceptar",
              }).then((confirm) => {
                if (confirm) {
                  this.$emit("refresh-table");

                  this.salirDialog();
                }
              });
            } else {
              this.$swal({
                title: "Error",
                text: response.status,
                icon: "error",
                confirmButtonText: "Aceptar",
              });
            }
          }else{
             console.log("addC",this.dataCategoria)
            let response = await postCategoria(this.dataCategoria);

            if (response.status === 201 || response.status === 200) {
              this.$swal({
                  title: "Agregado correctamente",
                  icon: "success",
                  confirmButtonText: "Aceptar",
                }).then((confirm) => {
                  if (confirm) {
                    this.$emit("refresh-table");
                    this.salirDialog();
                  }
                });
            } else {
              this.$swal({
                title: "Error",
                text: response.status,
                icon: "error",
                confirmButtonText: "Aceptar",
              });
            }
          }
        }
      }
    },
  }
</script>


<style lang="scss" scoped></style>
