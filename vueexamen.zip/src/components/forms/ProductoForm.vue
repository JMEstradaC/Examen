<template>
    <div />
</template>

<script>
  export default {
    name: 'ProductoForm',
    data() {
      return {
        key: value,
      }
    },
    methods: {
      name() {},
    },
  }
</script>

<style lang="scss" scoped></style>
