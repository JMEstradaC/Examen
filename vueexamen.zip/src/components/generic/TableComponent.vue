<template>
    <div>
        <v-card
            color="primary"
            tile
        >
            <v-card-title class="headline">
                <v-row v-if="isCrud === true">
                    <v-col cols="12">
                        <v-btn
                            class="mx-2"
                            fab
                            bottom
                            left
                            dark
                            small
                            color="green"
                            @click="abrirForm()"
                        >
                            <v-icon dark>
                                mdi-plus
                            </v-icon>
                        </v-btn>
                        <span style="color:#FFF;font-size: medium;">{{ titleTable }}</span>
                    </v-col>
                </v-row>
                <v-spacer />
                <v-text-field
                    v-if="requiredSearch"
                    v-model="search"
                    append-icon="mdi-magnify"
                    label="Buscar"
                    single-line
                    hide-details
                    solo
                    dense
                />
            </v-card-title>
            <v-data-table
                class="elevation-1"
                :headers="headers"
                :items="items"
                :search="search"
                :items-per-page="10"
                :loading="loading"
                loading-text="Cargando... Por favor espere"
                locale="es-ES"
                single-line
                hide-details
            >
                <template
                    v-if="acctionsTable === 2"
                    v-slot:[`item.idEstatus`]="{ item }"
                >
                    <v-chip
                        :color="getColor(item.idEstatus)"
                        dark
                    >
                        {{ item.Estatus }}
                    </v-chip>
                </template>

                <template v-slot:[`item.acciones`]="{ item }">
                    <v-tooltip
                        v-for="(elemento, index) in item.acciones"
                        :key="index"
                        bottom
                    >
                        <template v-slot:activator="{ on }">
                            <v-btn
                                text
                                icon
                                :color="elemento.iconColor"
                                v-on="on"
                                @click="elemento.accion(item)"
                            >
                                <v-icon>{{ elemento.icon }}</v-icon>
                            </v-btn>
                        </template>
                        <span>{{ elemento.tooltip }}</span>
                    </v-tooltip>
                </template>
            </v-data-table>
        </v-card>
    </div>
</template>

<script>
  export default {
    name: 'TableComponent',
    components: {
    // ModalMsjConfirm,
    },
    props: {
      titleTable: {
        type: String,
        required: true,
      },
      headers: {
        type: Array,
        required: true,
      },
      itemsTable: {
        type: Array,
        required: true,
      },
      acctionsTable: {
        type: Number,
        required: false,
        default: 1,
      },
      requiredSearch: {
        type: Boolean,
        required: false,
        default: true,
      },
      isCrud: {
        type: Boolean,
        required: false,
        default: false,
      },
    },
    data() {
      return {
        dialog: false,
        search: '',
        loading: true,
        item: [],
        objItem: null,
        tipoMsj: 0,
        msjDialog: '',
        acciones: [],
        acciones_b: [
          {
            // acciones base
            accion: this.openEdit,
            icon: 'mdi-pencil',
            iconColor: 'blue',
            tooltip: 'Editar',
          },
          {
            accion: this.openDelete,
            icon: 'mdi-delete',
            iconColor: 'red',
            tooltip: 'Eliminar',
          },
        ],
      }
    },
    watch: {
      itemsTable: {
        immediate: true,
        deep: true,
        handler(newValue, oldValue) {
          // console.log(oldValue);
          if (newValue) {
            // this.loading = true;
            this.mapItemsData()
          }
        },
      },
    },
    mounted() {},
    methods: {
      mapItemsData() {
        var self = this
        self.loading = true

        try {
          var items = self.itemsTable

          switch (this.acctionsTable) {
            case 1:
              this.acciones = this.acciones_b

              this.acciones[0].tooltip = 'Editar'
              this.acciones[1].tooltip = 'Eliminar'

              self.items = items.map(e => {
                e.acciones = this.acciones
                return e
              })
              break
            default:
              this.acciones = this.acciones_b

              this.acciones[0].tooltip = 'Editar'
              this.acciones[1].tooltip = 'Eliminar'

              self.items = items.map(e => {
                e.acciones = this.acciones
                return e
              })
              break
          }

          self.loading = false
        } catch (e) {
          self.loading = false
          self.items = []
          console.log(e)
        }
      },
      abrirForm() {
        this.$emit('open-form', true)
      },
      openEdit(item) {
        this.$emit('item-edit', item)
      },
      openDelete(item) {
        this.tipoMsj = 3
        this.msjDialog = '¿Realmente quiere eliminar este elemento?'
        this.objItem = item
      },
      eliminarItem(resp) {
        if (resp) {
          this.$emit('item-delete', this.objItem)
        }
      },
      getColor(idEstatus) {
        switch (idEstatus) {
          case 0:
            return ''
            break
          case 1:
            return 'red'
            break
          case 2:
            return 'deep-purple'
            break
          case 3:
            return 'teal'
            break
          case 4:
            return 'orange'
            break
          case 5:
            return 'green'
            break
          default:
            return ''
            break
        }
      },
    },
  }
</script>

<style>
/* .v-data-table td {
    font-size: 2.875rem;
    height: 48px;
} */
</style>
