import axios from 'axios'
//import store from '@/store'

export const axiosSingleton = (function createSingleton() {
    let instance = null

    async function createInstance() {
        instance = axios.create({
          baseURL: process.env.NODE_ENV === 'production' ? `https://pvelate.azurewebsites.net/api` : `https://localhost:44305/api`,
                // withCredentials: false,
                headers: {
                    Accept: 'application/json, multipart/form-data',
                    'Content-Type': 'application/json'
                }
            })
        window.axiosInstance = instance
    }

    function getInstance() {
        if (!instance) { this.createInstance() }
        return instance
    }

    return {
        createInstance,
        getInstance
    }
})()
