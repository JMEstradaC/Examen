// Automatically included in './src/main.js'

import './app'
import './chartist'
import './webfontloader'
import './vue-meta'
