module.exports = {
    root: true,

    env: {
        node: true,
    },

    plugins: ['vuetify'],

    extends: 'vuetify',

    parserOptions: {
        parser: 'babel-eslint',
        ecmaVersion: 7,
        sourceType: "module",
        ecmaFeatures: {
            globalReturn: false,
            impliedStrict: false,
            jsx: true,
            experimentalObjectRestSpread: true,
            allowImportExportEverywhere: false
        }
    },

    rules: {
        "vue/html-indent": ["error", 4],
        "space-before-function-paren": ["error", "never"],
        "space-before-blocks": ["error", "always"],
        "object-curly-spacing": ["error", "always"],
        "no-console": process.env.NODE_ENV === "production" ? "error" : "off",
        "no-debugger": process.env.NODE_ENV === "production" ? "error" : "off",
        "quotes": [2, "single", { "avoidEscape": true }],
        "quotes": ["error", "single"],
        "jsx-quotes": [2, "prefer-single"],
    },

    overrides: [{
        files: [
            '**/__tests__/*.{j,t}s?(x)',
            '**/tests/unit/**/*.spec.{j,t}s?(x)',
        ],
        env: {
            jest: true,
        },
    }, ],
}