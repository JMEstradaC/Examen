module.exports = {
    devServer: {
        disableHostCheck: true,
    },

    transpileDependencies: ['vuetify'],
    chainWebpack: config => {
        config.module.rules.delete('eslint');
    }
}