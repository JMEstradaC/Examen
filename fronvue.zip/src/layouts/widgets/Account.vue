<template>
  <v-menu
    bottom
    left
    min-width="200"
    offset-y
    origin="top right"
    transition="scale-transition"
  >
    <template v-slot:activator="{ attrs, on }">
      <v-btn
        class="ml-2"
        min-width="0"
        text
        v-bind="attrs"
        v-on="on"
      >
        <v-icon>mdi-account</v-icon>
      </v-btn>
    </template>

    <v-list
      :tile="false"
      flat
      nav
    >

      
      <v-list-item-group
        v-model="selectedItem"
        color="primary"
      >
      <v-list-item @click="logout">
         <v-list-item-title >Salir</v-list-item-title>
          </v-list-item>

        <!-- <v-list-item
          v-for="(item, i) in items"
          :key="i"
        >
          <v-list-item-icon>
            <v-icon v-text="item.icon"></v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title v-text="item.text"></v-list-item-title>
          </v-list-item-content>
        </v-list-item> -->
      </v-list-item-group>
  
    	<!-- <v-list-item v-for="item in items" :key="item.title" @click="item.method"> -->
    
       <!-- <v-list-item @click="logout"> -->
    </v-list>
  
  </v-menu>
</template>

<script>
  export default {
    name: 'DefaultAccount',

    data: () => ({
      selectedItem:[],
      profile: [
        { title: 'Perfil' },
        { title: 'Configuracion' },
        { divider: true },
        { title: 'Log out' ,  method: () => this.logout() },
      ],
    }),
     methods: {
      logout: function () {
        this.$store.dispatch('logout')
        .then(() => {
          this.$router.push('/login')
        })
      }
    },
  }
</script>
