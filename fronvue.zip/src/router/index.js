// Imports
import Vue from 'vue'
import Router from 'vue-router'
import store from '../store'
import { trailingSlash } from '@/util/helpers'
import DefaultLayout from '@/layouts/Index'
Vue.use(Router)

const router = new Router({
    mode: 'history',
    base: process.env.BASE_URL,
    scrollBehavior: (to, from, savedPosition) => {
        if (to.hash) return { selector: to.hash }
        if (savedPosition) return savedPosition

        return { x: 0, y: 0 }
    },
    routes: [{
            props: true,
            path: '/',
            component: DefaultLayout,
            children: [{
                    path: '/',
                    name: 'Dashboard',
                    // meta: { authorize: [117, 141] },
                    component: () =>
                        import ('@/views/Dashboard'),
                        meta: { 
                            requiresAuth: true
                          }
                },
                {
                    path: '/components/profile',
                    name: 'UserProfile',
                    // meta: { authorize: [117, 141] },
                    component: () =>
                        import ('@/views/UserProfile'),
                        meta: { 
                            requiresAuth: true
                          }
                },
                {
                    path: '/components/productos',
                    name: 'Productos',
                    // meta: { authorize: [117, 141] },
                    component: () =>
                        import ('@/views/Productos'),
                },
                {
                    path: '/components/pedidos',
                    name: 'Pedidos',
                    // meta: { authorize: [117, 141] },
                    component: () =>
                        import ('@/views/Pedidos'),
                        meta: { 
                            requiresAuth: true
                          }
                },
                {
                    path: '/components/franquicia',
                    name: 'Franquicia',
                    // meta: { authorize: [117, 141] },
                    component: () =>
                        import ('@/views/Franquicia'),
                        meta: { 
                            requiresAuth: true
                          }
                },
            ],
        },
        {
            path: '/login',
            name: 'Login',
            component: () =>
                import ('@/views/Login'),
            meta: {
                isPublic: true,
            },
        },
    ],
})

router.beforeEach((to, from, next) => {
    if(to.matched.some(record => record.meta.requiresAuth)) {
      if (store.getters.isLoggedIn) {
        //   console.log("logueado");
        next()
        return
      }
      next('/login') 
    } else {
      next() 
    }
  })

// router.beforeEach((to, from, next) => {
//     return to.path.endsWith('/') ? next() : next(trailingSlash(to.path))
// })

export default router
