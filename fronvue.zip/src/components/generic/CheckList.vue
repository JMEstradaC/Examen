<template>
    <div>
         <!-- <v-card-title class="indigo white--text text-h5">
          {{model}}
        </v-card-title>   -->
           <v-list shaped>
  <!-- v-on:change="$emit('change', $event.target.checked)" -->
                    <v-list-item-group v-model="model">
                      <template v-for="(item, i) in itemsList">
                          
                        <v-divider
                          v-if="!item"
                          :key="`divider-${i}`"
                        ></v-divider>

                        <v-list-item
                          v-else
                          :key="`item-${i}`"
                          :value="item"
                          active-class="deep-purple--text text--accent-4"
                        >
                        <!-- @click="openEdit(item)" -->
                          <template v-slot:default="{ active }">
                            <v-list-item-content>
                              <v-list-item-title
                                v-text="item.categoria"
                              ></v-list-item-title>
                            </v-list-item-content>

                            <v-list-item-action>
                              <v-checkbox
                                :input-value="active"
                                color="deep-purple accent-4"
                              ></v-checkbox>
                            </v-list-item-action>
                          </template>
                        </v-list-item>
                      </template>
                    </v-list-item-group>
                  </v-list>
    </div>
    
</template>

<script>
  export default {
    name: 'CheckList',
    components: {
    },
    props: {
      itemsList: {
        type: Array,
        required: true,
      },
    },
    data() {
      return {
        dialog: false,
        search: '',
        loading: true,
        item: [],
        objItem: null,
        tipoMsj: 0,
        msjDialog: '',
        acciones: [],
        model: [],
      }
    },
    watch: {
      model: function(model) {
    //   console.log("model",model);
       this.$emit('item-asign', model)
    },
      itemsList: {
        immediate: true,
        deep: true,
        handler(newValue, oldValue) {
             console.log("saluds dede list",oldValue);
          // console.log(oldValue);
          if (newValue) {
            // this.loading = true;
            this.mapItemsData()
          }
        },
      },
     
    },
    mounted() {},
    methods: {
      mapItemsData() {
        var self = this
        try {
          var items = self.itemsList
          console.log("l items",items);
        } catch (e) {
          self.items = []
          console.log(e)
        }
      },
        openEdit(item) {
            console.log("opem",item);
        this.$emit('item-asign', item)
      },
    

    },
  }
</script>

<style>
/* .v-data-table td {
    font-size: 2.875rem;
    height: 48px;
} */
</style>
