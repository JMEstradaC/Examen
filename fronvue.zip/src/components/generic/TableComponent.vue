<template>
  <div>
    <material-card color="primary" full-header>
      <template #heading v-if="requiredSearch || isCrud">
        <v-row v-if="isCrud === true">
          <v-col cols="12">
            <div class="pa-4 white--text">
              <div class="text-h4 font-weight-light">
                <v-btn
                  class="mx-2"
                  fab
                  bottom
                  left
                  dark
                  small
                  color="green"
                  @click="abrirForm()"
                >
                  <v-icon dark> mdi-plus </v-icon>
                </v-btn>
                <span style="color: #fff; font-size: medium">{{
                  titleTable
                }}</span>
              </div>
            </div>
          </v-col>
        </v-row>
        <v-spacer />
        <v-text-field
          v-if="requiredSearch"
          v-model="search"
          append-icon="mdi-magnify"
          label="Buscar"
          single-line
          hide-details
          solo
          dense
        />
      </template>
      <v-data-table
        class="elevation-1"
        :headers="headers"
        :items="items"
        :search="search"
        :items-per-page="10"
        :loading="loading"
        loading-text="Cargando... Por favor espere"
        locale="es-ES"
        single-line
        hide-details
      >
        <template
          v-if="acctionsTable === 2"
          v-slot:[`item.idEstatus`]="{ item }"
        >
          <v-chip :color="getColor(item.idEstatus)" dark>
            {{ item.Estatus }}
          </v-chip>
        </template>

        <template v-slot:[`item.acciones`]="{ item }">
          <v-tooltip
            v-for="(elemento, index) in item.acciones"
            :key="index"
            bottom
          >
            <template v-slot:activator="{ on }">
              <v-btn
                text
                icon
                :color="elemento.iconColor"
                v-on="on"
                @click="elemento.accion(item)"
              >
                <v-icon>{{ elemento.icon }}</v-icon>
              </v-btn>
            </template>
            <span>{{ elemento.tooltip }}</span>
          </v-tooltip>
        </template>
      </v-data-table>
    </material-card>
  </div>
</template>

<script>
export default {
  name: "TableComponent",
  components: {
    // ModalMsjConfirm,
  },
  props: {
    titleTable: {
      type: String,
      required: false,
      default: "",
    },
    headers: {
      type: Array,
      required: true,
    },
    itemsTable: {
      type: Array,
      required: true,
    },
    acctionsTable: {
      type: Number,
      required: false,
      default: 1,
    },
    requiredSearch: {
      type: Boolean,
      required: false,
      default: true,
    },
    isCrud: {
      type: Boolean,
      required: false,
      default: false,
    },
  },
  data() {
    return {
      dialog: false,
      search: "",
      loading: true,
      item: [],
      objItem: null,
      acciones: [],
      acciones_b: [
        {
          // acciones base
          accion: this.openEdit,
          icon: "mdi-pencil",
          iconColor: "blue",
          tooltip: "Editar",
        },
        {
          accion: this.openDelete,
          icon: "mdi-delete",
          iconColor: "red",
          tooltip: "Eliminar",
        },
      ],
      acciones_p: [
        {
          accion: this.openRelacionados,
          icon: "mdi-rice",
          iconColor: "green",
          tooltip: "Ver productos",
        },
        {
          accion: this.openStock,
          icon: "mdi-stove",
          iconColor: "purple",
          tooltip: "Ver insumos",
        },
        {
          accion: this.openEdit,
          icon: "mdi-pencil",
          iconColor: "blue",
          tooltip: "Editar",
        },
        {
          accion: this.openDelete,
          icon: "mdi-delete",
          iconColor: "red",
          tooltip: "Eliminar",
        },
      ],
    };
  },
  watch: {
    itemsTable: {
      immediate: true,
      deep: true,
      handler(newValue, oldValue) {
        // console.log(oldValue);
        if (newValue) {
          // this.loading = true;
          this.mapItemsData();
        }
      },
    },
  },
  mounted() {},
  methods: {
    mapItemsData() {
      var self = this;
      self.loading = true;

      try {
        var items = self.itemsTable;

        switch (this.acctionsTable) {
          case 1:
            this.acciones = this.acciones_b;

            this.acciones[0].tooltip = "Editar";
            this.acciones[1].tooltip = "Eliminar";

            self.items = items.map((e) => {
              e.acciones = this.acciones;
              return e;
            });
            break;
          case 2:
            this.acciones = this.acciones_p;

            this.acciones[0].tooltip = "Ver insumos";
            this.acciones[1].tooltip = "Editar";
            this.acciones[2].tooltip = "Eliminar";

            self.items = items.map((e) => {
              e.acciones = this.acciones;
              return e;
            });
            break;
          case 3:
            this.acciones = this.acciones_p;

            this.acciones[0].tooltip = "Ver productos";
            this.acciones[1].tooltip = "Ver insumos";
            this.acciones[2].tooltip = "Editar";
            this.acciones[3].tooltip = "Eliminar";

            self.items = items.map((e) => {
              e.acciones = this.acciones;
              return e;
            });
            break;
          default:
            this.acciones = this.acciones_b;

            this.acciones[0].tooltip = "Editar";
            this.acciones[1].tooltip = "Eliminar";

            self.items = items.map((e) => {
              e.acciones = this.acciones;
              return e;
            });
            break;
        }

        self.loading = false;
      } catch (e) {
        self.loading = false;
        self.items = [];
        console.log(e);
      }
    },
    abrirForm() {
      this.$emit("open-form", true);
    },
    openEdit(item) {
      this.$emit("item-edit", item);
    },
    openRelacionados(item) {
      this.$emit("consulta-relacionados", item);
    },
    openStock(item) {
      this.$emit("consulta-stock", item);
    },
    openDelete(item) {
      this.$swal({
        title: "Eliminar registro",
        text: "¿Desea eliminar este registro?",
        icon: "warning",
        confirmButtonText: "Confirmar",
        showCancelButton: true,
        cancelButtonText: "Cancelar",
      }).then((willDelete) => {
        if (willDelete.isConfirmed) {
          this.$emit("item-delete", item);
        }
      });
    },
    getColor(idEstatus) {
      switch (idEstatus) {
        case 0:
          return "";
          break;
        case 1:
          return "red";
          break;
        case 2:
          return "deep-purple";
          break;
        case 3:
          return "teal";
          break;
        case 4:
          return "orange";
          break;
        case 5:
          return "green";
          break;
        default:
          return "";
          break;
      }
    },
  },
};
</script>

<style>
/* .v-data-table td {
    font-size: 2.875rem;
    height: 48px;
} */
</style>
