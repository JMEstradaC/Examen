<template>
  <v-dialog v-model="dialog"
            persistent
            max-width="800px">

    <v-card class="mx-auto">
      <v-card-title>
        <span class="headline">Agregar insumo a {{dataProducto.nombre}}</span>
      </v-card-title>
      <v-card-text>
        <v-container>
          <v-row dense>
            <v-col cols="8">
              <table-component :headers="hInsumosP"
                               :items-table="listInsumosProducto"
                               :is-crud="false"
                               :required-search="false"
                               @item-edit="actualizar"
                               @item-delete="eliminar" />
            </v-col>
            <v-col cols="4">
              <v-form ref="form"
                      v-model="valid"
                      lazy-validation
                      @submit.prevent="guardar">
                <v-card class="mx-auto">
                  <v-card-text>
                    <v-autocomplete v-model="idIns"
                                    :items="items"
                                    color="blue-grey lighten-2"
                                    label="Seleccionar insumo"
                                    item-text="nombreInsumo"
                                    item-value="idInsumo"
                                    cache-items
                                    flat
                                    hide-details
                                    @change="selectInsumo()">

                      <template v-slot:no-data>
                        <v-list-item>
                          <v-list-item-title>
                            Sin resultados
                          </v-list-item-title>
                        </v-list-item>
                      </template>
                      <template v-slot:selection="{ attr, on, item, selected }">
                        <span v-text="item.nombreInsumo" />
                      </template>
                      <template v-slot:item="{ item }">
                        <v-list-item-content>
                          <v-list-item-title v-text="item.nombreInsumo" />
                        </v-list-item-content>
                      </template>
                    </v-autocomplete>

                    <v-text-field v-model="dataProductoInsumo.cantidadInsumo"
                                  :counter="15"
                                  :rules="[v => !!v || 'Cantidad requerida']"
                                  label="Cantidad"
                                  required />

                  </v-card-text>
                  <v-card-actions>
                    <v-spacer />
                    <v-btn v-if="!isUpdate"
                           color="success"
                           small
                           class="mr-4"
                           type="submit">
                      Guardar
                    </v-btn>
                    <v-btn v-else color="success"
                           small
                           class="mr-4"
                           type="submit">
                      Actualizar
                    </v-btn>

                    <v-btn color="error"
                           small
                           class="mr-4"
                           @click="reset">
                      Cancelar
                    </v-btn>
                  </v-card-actions>

                </v-card>
              </v-form>
            </v-col>
          </v-row>
        </v-container>
      </v-card-text>
      <v-card-actions>
        <v-spacer />
        <v-btn color="warning"
               small
               class="mr-4"
               @click="salirDialog">
          Salir
        </v-btn>
      </v-card-actions>
    </v-card>

  </v-dialog>
</template>

<script>
  import {
    getListInsumo,
    getListProdInsumo,
    putProdInsumo,
    postProdInsumo,
    deleteProdInsumo,
  } from "@/api/productosApi";

  export default {
    name: "ProductosInsumosCrud",
    props: {
      showDialog: {
        type: Boolean,
        required: true,
      },
      objProducto: {
        type: Object,
        required: true,
      },
    },
    data() {
      return {
        dialog: false,
        isUpdate: false,
        valid: true,
        items: null,
        idIns: null,
        dataProducto: {},
        dataProductoInsumo: {
          idProductoInsumo: 0,
          idProducto: 0,
          idInsumo: 0,
          cantidadInsumo: null,
        },
        listInsumosProducto: [],
        hInsumosP: [
          {
            text: "Cantidad",
            value: "insumoCantidad",
          },
          {
            text: "Insumo",
            value: "insumo",
          },
          {
            text: "Admin",
            value: "acciones",
          },
        ],
      };
    },
    watch: {
      showDialog: {
        immediate: true,
        deep: true,
        handler(newValue, oldValue) {
          this.dialog = newValue;
          this.isUpdate = false;
          //this.reset()
        },
      },
      objProducto: {
        immediate: true,
        deep: true,
        handler(newValue, oldValue) {
          this.dataProducto = newValue;
          //Se asigna id de produto al objeto form que se enviara
          this.dataProductoInsumo.idProducto = newValue.idProducto;

          if (this.dataProducto.idProducto) {
            this.getProdInsumo();
            this.reset()
          }
        },
      },
    },
    mounted() {
      // this.$refs.form.reset();
      this.getInsumos();

    },
    methods: {
      salirDialog() {
        //this.reset()
        this.$emit("close-form", false);
      },
      async getInsumos() {
        try {
          const response = await getListInsumo();
          this.items = response.data;
        } catch (e) {
          this.$swal({
            title: "Error",
            text: e.toString(),
            icon: "error",
            confirmButtonText: "Aceptar",
          });
        }
      },
      async getProdInsumo() {
        try {
          const response = await getListProdInsumo(this.dataProducto.idProducto);
          this.listInsumosProducto = response.data;
        } catch (e) {
          this.$swal({
            title: "Error",
            text: e.toString(),
            icon: "error",
            confirmButtonText: "Aceptar",
          });
        }
      },
      selectInsumo() {
        if (this.idIns) {
          this.dataProductoInsumo.idInsumo = this.idIns;
        }
      },
      validarForm() {
        return this.$refs.form.validate();
      },
      reset() {
        this.$refs.form.reset();
        this.isUpdate = false;
      },
      actualizar(item) {
        this.isUpdate = true;
        this.dataProductoInsumo = item;
        this.idIns = item.idInsumo
      },
      async guardar() {
        if (this.validarForm()) {
          if (this.isUpdate) {
            let response = await putProdInsumo(
              this.dataProductoInsumo.idProductoInsumo,
              this.dataProductoInsumo
            );
            if (response.status === 204) {
              this.$swal({
                title: "Actualizado correctamente",
                icon: "success",
                confirmButtonText: "Aceptar",
              })
               .then((confirm) => {
                 if (confirm) {
                   this.getProdInsumo();
                   this.reset();
                 }
               });
            } else {
              this.$swal({
                title: "Error",
                text: response.status,
                icon: "error",
                confirmButtonText: "Aceptar",
              });
            }
          } else {
            let response = await postProdInsumo(this.dataProductoInsumo);

            if (response.status === 201 || response.status === 200) {
              this.$swal({
                title: "Agregado correctamente",
                icon: "success",
                confirmButtonText: "Aceptar",
              }).then((confirm) => {
                if (confirm) {
                  this.getProdInsumo();
                }
              });
            } else {
              this.$swal({
                title: "Error",
                text: response.status,
                icon: "error",
                confirmButtonText: "Aceptar",
              });
            }
          }
        }
      },
      async eliminar(item) {
        const response = await deleteProdInsumo(item.idProductoInsumo)

        if (response.status === 204 || response.status === 200) {
          const index = this.listInsumosProducto.indexOf(item)
          this.listInsumosProducto.splice(index, 1)
        } else {
          this.$swal({
            title: "Error",
            text: response.status,
            icon: "error",
            confirmButtonText: "Aceptar",
          });
        }
      },
    },
  };
</script>


<style lang="scss" scoped></style>
