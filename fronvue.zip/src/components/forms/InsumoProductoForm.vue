<template>
    <v-dialog
        v-model="dialog"
        persistent
        max-width="400px"
    >
        <v-form
            ref="form"
            v-model="valid"
            lazy-validation
            @submit.prevent="guardar"
        >
            <v-card>
                <v-card-title>
                    <span
                        v-if="!isUpdate"
                        class="headline"
                    >Agregar insumo</span>
                    <span
                        v-else
                        class="headline"
                    >Actualizar insumo</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-text-field
                            v-model="dataInsumo.nombre"
                            :counter="40"
                            :rules="[v => !!v || 'Nombre de insumo requerido']"
                            label="Nombre"
                            required
                        />
                        <v-text-field
                            v-model="dataInsumo.codigoReferencia"
                            :counter="15"
                            :rules="[v => !!v || 'Código requerido']"
                            label="Código de referencia"
                            required
                        />
                        <v-autocomplete
                            v-model="unidadM"
                            :items="items"
                            color="blue-grey lighten-2"
                            label="Seleccionar unidad de medida"
                            item-text="nombre"
                            item-value="idUnidadMedida"
                            cache-items
                            flat
                            hide-details
                            @change="selectIcon()"
                        >
                            <template v-slot:no-data>
                                <v-list-item>
                                    <v-list-item-title>
                                        Sin resultados
                                    </v-list-item-title>
                                </v-list-item>
                            </template>
                            <template v-slot:selection="{ attr, on, item, selected }">
                                <span v-text="item.nombre" />
                            </template>
                            <template v-slot:item="{ item }">
                                <v-list-item-content>
                                    <v-list-item-title v-text="item.nombre" />
                                </v-list-item-content>
                            </template>
                        </v-autocomplete>
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer />
                    <v-btn
                        color="success"
                        class="mr-4"
                        type="submit"
                    >
                        Guardar
                    </v-btn>

                    <v-btn
                        color="error"
                        class="mr-4"
                        @click="salirDialog"
                    >
                        Cancelar
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-form>
    </v-dialog>
</template>

<script>
  import { getListUnidad,putInsumo,postInsumo } from '@/api/productosApi'

  export default {
    name: 'InsumoProductoForm',
    props: {
      showDialog: {
        type: Boolean,
        required: true,
      },
      objInsumo: {
        type: Object,
        required: true,
      },
      isUpdate: {
        type: Boolean,
        required: false,
        default: false,
      },
    },
    data() {
      return {
        dialog: false,
        valid: true,
        items: null,
        unidadM: null,
        dataInsumo: {
          idInsumo: 0,
          idMedida: 0,
          nombre: '',
          codigoReferencia: ''
        },
      }
    },
    watch: {
      showDialog: {
        immediate: true,
        deep: true,
        handler(newValue, oldValue) {
          this.dialog = newValue
        },
      },
      objInsumo: {
        immediate: true,
        deep: true,
        handler(newValue, oldValue) {

          if (this.isUpdate) {

            this.dataInsumo = newValue
            this.unidadM = newValue.idMedida
            this.dataInsumo.nombre = newValue.nombreInsumo
          }else{
            this.dataInsumo = {}
            this.unidadM = null
          }
        },
      },
    },
    mounted() {
      // this.$refs.form.reset();
      this.getUnidadM()
    },
    methods: {
      salirDialog() {
        //this.reset()
        this.$emit('close-form', false)
      },
      async getUnidadM() {
        try {
          const response = await getListUnidad()
          this.items = response.data
        } catch (e) {
          this.$swal({
            title: 'Error',
            text: e.toString(),
            icon: 'error',
            confirmButtonText: 'Aceptar',
          })
        }
      },
      selectIcon() {
        if (this.unidadM) {
          this.dataInsumo.idMedida = this.unidadM
        }
      },
      validarForm() {
        return this.$refs.form.validate()
      },
      reset() {
       this.$refs.form.reset()
      },
      async guardar(){

        if(this.validarForm()){

          if(this.isUpdate){

            let response = await putInsumo(
              this.dataInsumo.idInsumo,
              this.dataInsumo
            );
            if (response.status === 204) {
              this.$swal({
                title: "Actualizado correctamente",
                icon: "success",
                confirmButtonText: "Aceptar",
              }).then((confirm) => {
                if (confirm) {
                  this.$emit("refresh-table");

                  this.salirDialog();
                }
              });
            } else {
              this.$swal({
                title: "Error",
                text: response.status,
                icon: "error",
                confirmButtonText: "Aceptar",
              });
            }
          }else{
             console.log(this.dataInsumo)
            let response = await postInsumo(this.dataInsumo);

            if (response.status === 201 || response.status === 200) {
              this.$swal({
                  title: "Agregado correctamente",
                  icon: "success",
                  confirmButtonText: "Aceptar",
                }).then((confirm) => {
                  if (confirm) {
                    this.$emit("refresh-table");
                    this.salirDialog();
                  }
                });
            } else {
              this.$swal({
                title: "Error",
                text: response.status,
                icon: "error",
                confirmButtonText: "Aceptar",
              });
            }
          }
        }
      }
    },
  }
</script>


<style lang="scss" scoped></style>
