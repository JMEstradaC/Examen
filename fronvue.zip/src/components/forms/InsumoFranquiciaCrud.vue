<template>
  <v-dialog v-model="dialog" fullscreen hide-overlay>
    <v-card class="mx-auto">
      <v-toolbar dark color="accent">
        <v-toolbar-title
          >Agregar productos a {{ dataFranquicia.nombre }}</v-toolbar-title
        >
        <v-spacer />
        <v-toolbar-items>
          <v-btn icon dark @click="salirDialog()">
            <v-icon>mdi-close</v-icon>
          </v-btn>
        </v-toolbar-items>
      </v-toolbar>
      <v-card-text>
        <v-container>
          <v-row dense>
            <v-col cols="8">
              <table-component
                :headers="hProductos"
                :items-table="listStockFranquicia"
                :is-crud="false"
                :required-search="true"
                @item-edit="actualizar"
                @item-delete="eliminar"
              />
            </v-col>
            <v-col cols="4">
              <InsumoFranquiciaForm
                :is-update="isUpdate"
                :id-franquicia="dataStock.idFranquicia"
                :item-stock="dataStock"
                @refresh-table="getStock"
              />
            </v-col>
          </v-row>
        </v-container>
      </v-card-text>
    </v-card>
  </v-dialog>
</template>

<script>
import {
  getListStockFranquicia,
  deleteStockFranquicia,
} from "@/api/franquiciasApi";

import InsumoFranquiciaForm from "./InsumoFranquiciaForm.vue";

  export default {
    name: 'InsumoFranquiciaCrud',
     components: {
     InsumoFranquiciaForm,
  },
  props: {
    showDialog: {
      type: Boolean,
      required: true,
    },
    objFranquicia: {
      type: Object,
      required: true,
    },
  },
   data() {
    return {
      dialog: false,
      isUpdate: false,
      dataFranquicia: {},
      dataStock: {},
      listStockFranquicia: [],
      hProductos: [
        {
          text: "Cantidad",
          value: "cantidad",
        },
        {
          text: "Insumo",
          value: "nombre",
        },
        {
          text: "Precio ",
          value: "precioCompra",
        },
         {
          text: "Fecha alta ",
          value: "fechaAlta",
        },
        {
          text: "Admin",
          value: "acciones",
        },
      ],
    };
  },
  watch: {
    showDialog: {
      immediate: true,
      deep: true,
      handler(newValue, oldValue) {
        this.dialog = newValue;
      },
    },
    objFranquicia: {
      immediate: true,
      deep: true,
      handler(newValue, oldValue) {
        this.dataFranquicia = newValue;
        // Se asigna id de franquicia al objeto form que se enviara
        this.dataStock.idFranquicia = newValue.idFranquicia;

        if (this.dataFranquicia.idFranquicia) {
          this.getStock();
        }
      },
    },
  },
  mounted() {
  },
  methods: {
    salirDialog() {
      this.$emit("close-form");
    },
    async getStock() {
      var self = this;
      self.isUpdate = false
      try {
        const res = await getListStockFranquicia(
          self.dataFranquicia.idFranquicia
        );
        var its = res.data;
        self.listStockFranquicia = its;
      } catch (e) {
        this.errorMsj(e.toString())
      }
    },
    actualizar(item) {
      this.isUpdate = true;
      this.dataStock = item;
    },
    async eliminar(item) {
      const response = await deleteStockFranquicia(item.idStock);

      if (response.status === 204 || response.status === 200) {
        const index = this.listStockFranquicia.indexOf(item);
        this.listStockFranquicia.splice(index, 1);
      } else {
        this.errorMsj(response.status)
      }
    },
    errorMsj(msj) {
      this.$swal({
        title: "Error",
        text: msj,
        icon: "error",
        confirmButtonText: "Aceptar",
      });
    },
  },
};
</script>

<style lang="scss" scoped>

</style>
