<template>
  <v-dialog v-model="dialog" persistent max-width="400px">
    <v-form
      ref="form"
      v-model="valid"
      lazy-validation
      @submit.prevent="guardar"
    >
      <v-card>
        <v-card-title>
          <span class="headline">Actualizar Contraseña</span>
        </v-card-title>
        <v-card-text>
          <v-container>
              <v-text-field
            v-model="dataContrasena.pass"
            :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
            :rules="[rules.required, rules.min]"
            :type="show1 ? 'text' : 'password'"
            name="input-10-1"
            label="Nueva contraseña"
            hint="Minimo 8 carateres"
            counter
            required
            @click:append="show1 = !show1"
          ></v-text-field>
              <v-text-field
             v-model="dataContrasena.Repetir"
            :append-icon="show1 ? 'mdi-eye' : 'mdi-eye-off'"
            :rules="[rules.required, rules.min]"
            :type="show1 ? 'text' : 'password'"
            name="input-10-1"
            label="Nueva contraseña"
            hint="Minimo 8 carateres"
            counter
            required
            @click:append="show1 = !show1"
          ></v-text-field>
            <!-- <v-text-field
              v-model="dataContrasena.Contrasena"
              :counter="50"
              :rules="[(v) => !!v || 'Nueva contraseña']"
              label="Nueva contraseña"
              required
            /> -->
            <!-- <v-text-field
              v-model="dataContrasena.Repetir"
              :rules="[(v) => !!v || 'Repetir contraseña']"
              label="Repetir contraseña"
              required
            /> -->
          </v-container>
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn color="success" class="mr-4" type="submit"> Actualizar </v-btn>
          <v-btn color="error" class="mr-4" @click="salirDialog">
            Cancelar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-form>
      <v-snackbar
        v-model="showResult"
        :timeout="2000"
        color="primary"
        top>
        {{ result }}
      </v-snackbar>
  </v-dialog>
</template>

<script>
import { putUser } from "@/api/productosApi";

export default {
  name: "ContrasenaForm",
  props: {
    showDialog: {
      type: Boolean,
      required: true,
    },
    objUsuario: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      show1: false,
      showResult: false,
      result: '',
      dialog: false,
      valid: true,
      name: null,
      items: null,
      imgIcon: null,
      rules: {
          required: value => !!value || 'Requeridos.',
          min: v => v.length >= 8 || 'Minimo 8 caracteres',
        },
      dataContrasena: {
        idUsuario: 0,
        pass: "",
        Repetir: "",
        viejoId: 0,
      },
    };
  },
  watch: {
    showDialog: {
      immediate: true,
      deep: true,
      handler(newValue, oldValue) {
        this.dialog = newValue;
      },
    },
    // objUsuario: {
    //   immediate: true,
    //   deep: true,
    //   handler(newValue, oldValue) {
    //     if (this.isUpdate) {
    //       this.dataFranquicia = newValue;
    //       this.imgIcon = newValue.idImagen;
    //       this.dataFranquicia.nombre = newValue.nombre;
    //     } else {
    //       this.dataFranquicia = {};
    //       this.imgIcon = null;
    //     }
    //   },
    // },
  },
  mounted() {
    // this.$refs.form.reset();
  },
  methods: {
    salirDialog() {
      //this.reset()
      this.$emit("close-form", false);
    },
  
  
    validarForm() {
      return this.$refs.form.validate();
    },
    reset() {
      this.$refs.form.reset();
    },
    async guardar() {
     this.dataContrasena.idUsr=this.objUsuario.idUsr;
      if (this.dataContrasena.pass != this.dataContrasena.Repetir ) {   
        this.result = "Error al confirmar contraseña.";
        this.showResult = true;
        return;
      }
      if (this.validarForm()) {
          let response = await putUser(
            this.dataContrasena.idUsr,
            this.dataContrasena
          );
          if (response.status === 204) {
            this.$swal({
              title: "Actualizado correctamente",
              icon: "success",
              confirmButtonText: "Aceptar",
            }).then((confirm) => {
              if (confirm) {
                this.$emit("refresh-table");

                this.salirDialog();
              }
            });
          } else {
            this.$swal({
              title: "Error",
              text: response.status,
              icon: "error",
              confirmButtonText: "Aceptar",
            });
          }
      }
    },
  },
};
</script>


<style lang="scss" scoped></style>
