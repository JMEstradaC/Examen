<template>
  <v-dialog v-model="dialog" persistent max-width="400px">
    <v-form
      ref="form"
      v-model="valid"
      lazy-validation
      @submit.prevent="guardar"
    >
      <v-card>
        <v-card-title>
          <span v-if="!isUpdate" class="headline">Agregar franquicia</span>
          <span v-else class="headline">Actualizar franquicia</span>
        </v-card-title>
        <v-card-text>
          <v-container>
            <v-text-field
              v-model="dataFranquicia.nombre"
              :counter="50"
              :rules="[(v) => !!v || 'Nombre de categoría requerido']"
              label="Nombre"
              required
            />
            <v-text-field
              v-model="dataFranquicia.ubicación"
              :rules="[(v) => !!v || 'Ubicacion requerida']"
              label="Ubicacion"
              required
            />
            <v-text-field
              v-model="dataFranquicia.numeroCelular"
              :rules="[(v) => !!v || 'Telefono requerido']"
              label="Telefono"
              required
            />
            <v-text-field
              v-model="dataFranquicia.correo"
              :rules="[(v) => !!v || 'Correo requerido']"
              label="Correo"
              required
            />
          </v-container>
        </v-card-text>
        <v-card-actions>
          <v-spacer />
          <v-btn color="success" class="mr-4" type="submit"> Guardar </v-btn>

          <v-btn color="error" class="mr-4" @click="salirDialog">
            Cancelar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-form>
  </v-dialog>
</template>

<script>
import { putFranquicia, postFranquicia } from "@/api/productosApi";

export default {
  name: "FranquiciaForm",
  props: {
    showDialog: {
      type: Boolean,
      required: true,
    },
    objCategoria: {
      type: Object,
      required: true,
    },
    isUpdate: {
      type: Boolean,
      required: false,
      default: false,
    },
  },
  data() {
    return {
      dialog: false,
      valid: true,
      name: null,
      items: null,
      imgIcon: null,
      dataFranquicia: {
        idFranquicia: 0,
        ubicación: "",
        correo: "",
        nombre: "",
        numeroCelular: "",
        viejoId: 0,
      },
    };
  },
  watch: {
    showDialog: {
      immediate: true,
      deep: true,
      handler(newValue, oldValue) {
        this.dialog = newValue;
      },
    },
    objCategoria: {
      immediate: true,
      deep: true,
      handler(newValue, oldValue) {
        if (this.isUpdate) {
          this.dataFranquicia = newValue;
          this.imgIcon = newValue.idImagen;
          this.dataFranquicia.nombre = newValue.nombre;
        } else {
          this.dataFranquicia = {};
          this.imgIcon = null;
        }
      },
    },
  },
  mounted() {
    // this.$refs.form.reset();
  },
  methods: {
    salirDialog() {
      //this.reset()
      this.$emit("close-form", false);
    },
  
  
    validarForm() {
      return this.$refs.form.validate();
    },
    reset() {
      this.$refs.form.reset();
    },
    async guardar() {
        console.log(" this.dataFranquicia",this.dataFranquicia);
      if (this.validarForm()) {
        if (this.isUpdate) {
          let response = await putFranquicia(
            this.dataFranquicia.idFranquicia,
            this.dataFranquicia
          );
          if (response.status === 204) {
            this.$swal({
              title: "Actualizado correctamente",
              icon: "success",
              confirmButtonText: "Aceptar",
            }).then((confirm) => {
              if (confirm) {
                this.$emit("refresh-table");

                this.salirDialog();
              }
            });
          } else {
            this.$swal({
              title: "Error",
              text: response.status,
              icon: "error",
              confirmButtonText: "Aceptar",
            });
          }
        } else {
          console.log("addC", this.dataFranquicia);
          let response = await postFranquicia(this.dataFranquicia);

          if (response.status === 201 || response.status === 200) {
            this.$swal({
              title: "Agregado correctamente",
              icon: "success",
              confirmButtonText: "Aceptar",
            }).then((confirm) => {
              if (confirm) {
                this.$emit("refresh-table");
                this.salirDialog();
              }
            });
          } else {
            this.$swal({
              title: "Error",
              text: response.status,
              icon: "error",
              confirmButtonText: "Aceptar",
            });
          }
        }
      }
    },
  },
};
</script>


<style lang="scss" scoped></style>
