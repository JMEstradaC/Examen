<template>
    <v-dialog
        v-model="dialog"
        persistent
        max-width="400px"
    >
        <v-form
            ref="form"
            v-model="valid"
            lazy-validation
            @submit.prevent="guardar"
        >
            <v-card>
                <v-card-title>
                    <span
                        v-if="!isUpdate"
                        class="headline"
                    >Agregar producto</span>
                    <span
                        v-else
                        class="headline"
                    >Actualizar producto</span>
                </v-card-title>
                <v-card-text>
                    <v-container>
                        <v-text-field
                            v-model="dataProducto.nombre"
                            :counter="35"
                            :rules="[v => !!v || 'Nombre de producto requerido']"
                            label="Nombre"
                            required
                        />
                        <v-text-field
                            v-model="dataProducto.codigoReferencia"
                            :counter="15"
                            :rules="[v => !!v || 'Código requerido']"
                            label="Código de referencia"
                            required
                        />
                        <v-autocomplete
                            v-model="idCat"
                            :items="items"
                            color="blue-grey lighten-2"
                            label="Seleccionar categoria"
                            item-text="nombre"
                            item-value="idCategoria"
                            cache-items
                            flat
                            hide-details
                            @change="selectIcon()"
                        >
                            <template v-slot:no-data>
                                <v-list-item>
                                    <v-list-item-title>
                                        Sin resultados
                                    </v-list-item-title>
                                </v-list-item>
                            </template>
                            <template v-slot:selection="{ attr, on, item, selected }">
                                <span v-text="item.nombre" />
                            </template>
                            <template v-slot:item="{ item }">
                                <v-list-item-content>
                                    <v-list-item-title v-text="item.nombre" />
                                </v-list-item-content>
                            </template>
                        </v-autocomplete>
                        <v-checkbox
                            v-model="extra"
                            label="Aplica extra"
                            color="orange darken-3"
                            hide-details
                            @change="dataProducto.aplicaExtra = extra"
                        />
                    </v-container>
                </v-card-text>
                <v-card-actions>
                    <v-spacer />
                    <v-btn
                        color="success"
                        class="mr-4"
                        type="submit"
                    >
                        Guardar
                    </v-btn>
                    <v-btn
                        color="error"
                        class="mr-4"
                        @click="salirDialog"
                    >
                        Cancelar
                    </v-btn>
                </v-card-actions>
            </v-card>
        </v-form>
    </v-dialog>
</template>

<script>
  import {
    getListCategorias,
    putProducto,
    postProducto,
  } from '@/api/productosApi'

  export default {
    name: 'ProductoForm',
    props: {
      showDialog: {
        type: Boolean,
        required: true,
      },
      objProducto: {
        type: Object,
        required: true,
      },
      isUpdate: {
        type: Boolean,
        required: false,
        default: false,
      },
    },
    data() {
      return {
        dialog: false,
        valid: true,
        items: null,
        idCat: null,
        extra: false,
        dataProducto: {
          idProducto: 0,
          idCategoria: 0,
          nombre: '',
          codigoReferencia: '',
          viejoId: '',
          aplicaExtra: false,
        },
      }
    },
    watch: {
      showDialog: {
        immediate: true,
        deep: true,
        handler(newValue, oldValue) {
          this.dialog = newValue
        },
      },
      objProducto: {
        immediate: true,
        deep: true,
        handler(newValue, oldValue) {
          if (this.isUpdate) {
            this.dataProducto.idProducto = newValue.idProducto
            this.dataProducto.nombre = newValue.producto
            this.dataProducto.idCategoria = newValue.idCategoria
            this.dataProducto.codigoReferencia = newValue.codigoReferencia
            this.dataProducto.aplicaExtra = newValue.aplicaExtra
            this.dataProducto.viejoId = newValue.viejoId

            this.idCat = newValue.idCategoria
            this.extra = newValue.aplicaExtra
          } else {
            this.dataProducto = {}
            this.idCat = null
            this.extra = false
          }
        },
      },
    },
    mounted() {
      // this.$refs.form.reset();
      this.getCategorias()
    },
    methods: {
      salirDialog() {
        // this.reset()
        this.$emit('close-form', false)
      },
      async getCategorias() {
        try {
          const response = await getListCategorias()
          this.items = response.data
          console.log('revisar', this.items)
        } catch (e) {
          this.$swal({
            title: 'Error',
            text: e.toString(),
            icon: 'error',
            confirmButtonText: 'Aceptar',
          })
        }
      },
      selectIcon() {
        if (this.idCat) {
          this.dataProducto.idCategoria = this.idCat
        }
      },
      validarForm() {
        return this.$refs.form.validate()
      },
      reset() {
        this.$refs.form.reset()
      },
      async guardar() {
        if (this.validarForm()) {
          if (this.isUpdate) {
            const response = await putProducto(
              this.dataProducto.idProducto,
              this.dataProducto
            )
            if (response.status === 204) {
              this.$swal({
                title: 'Actualizado correctamente',
                icon: 'success',
                confirmButtonText: 'Aceptar',
              }).then(confirm => {
                if (confirm) {
                  this.$emit('refresh-table')

                  this.salirDialog()
                }
              })
            } else {
              this.$swal({
                title: 'Error',
                text: response.status,
                icon: 'error',
                confirmButtonText: 'Aceptar',
              })
            }
          } else {
            console.log(this.dataProducto)
            const response = await postProducto(this.dataProducto)

            if (response.status === 201 || response.status === 200) {
              this.$swal({
                title: 'Agregado correctamente',
                icon: 'success',
                confirmButtonText: 'Aceptar',
              }).then(confirm => {
                if (confirm) {
                  this.$emit('refresh-table')
                  this.salirDialog()
                }
              })
            } else {
              this.$swal({
                title: 'Error',
                text: response.status,
                icon: 'error',
                confirmButtonText: 'Aceptar',
              })
            }
          }
        }
      },
    },
  }
</script>

<style lang="scss" scoped></style>
