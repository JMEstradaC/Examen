<template>
  <v-dialog v-model="dialog" fullscreen hide-overlay>
    <v-card class="mx-auto">
      <v-toolbar dark color="accent">
        <v-toolbar-title
          >Agregar productos a {{ dataFranquicia.nombre }}</v-toolbar-title
        >
        <v-spacer />
        <v-toolbar-items>
          <v-btn icon dark @click="salirDialog()">
            <v-icon>mdi-close</v-icon>
          </v-btn>
        </v-toolbar-items>
      </v-toolbar>
      <v-card-text>
        <v-container>
          <v-row dense>
            <v-col cols="8">
              <table-component
                :headers="hProductos"
                :items-table="listProdFranquicia"
                :is-crud="false"
                :required-search="true"
                @item-edit="actualizar"
                @item-delete="eliminar"
              />
            </v-col>
            <v-col cols="4">
              <ProductoFranquiciaForm
                :is-update="isUpdate"
                :id-franquicia="dataProdFranquicia.idFranquicia"
                :item-producto="dataProdFranquicia"
                @refresh-table="getProductosFranquicia"
              />
            </v-col>
          </v-row>
        </v-container>
      </v-card-text>
      <!-- <v-card-actions>
                <v-spacer />
                <v-btn
                    color="warning"
                    small
                    class="mr-4"
                    @click="salirDialog"
                >
                    Salir
                </v-btn>
            </v-card-actions> -->
    </v-card>
  </v-dialog>
</template>

<script>
import {
  getListProductosFranquicia,
  deleteProductosFranquicia,
} from "@/api/franquiciasApi";

import ProductoFranquiciaForm from "./ProductoFranquiciaFrom.vue";

export default {
  name: "ProductosFranquiciaCrud",
  components: {
    ProductoFranquiciaForm,
  },
  props: {
    showDialog: {
      type: Boolean,
      required: true,
    },
    objFranquicia: {
      type: Object,
      required: true,
    },
  },
  data() {
    return {
      dialog: false,
      isUpdate: false,
      dataFranquicia: {},
      dataProdFranquicia: {},
      listProdFranquicia: [],
      hProductos: [
        {
          text: "Código",
          value: "codigoReferencia",
        },
        {
          text: "Nombre",
          value: "nombre",
        },
        {
          text: "Precio",
          value: "precioVenta",
        },
        {
          text: "Admin",
          value: "acciones",
        },
      ],
    };
  },
  watch: {
    showDialog: {
      immediate: true,
      deep: true,
      handler(newValue, oldValue) {
        this.dialog = newValue;
        //this.isUpdate = false;
        // this.reset()
      },
    },
    objFranquicia: {
      immediate: true,
      deep: true,
      handler(newValue, oldValue) {
        this.dataFranquicia = newValue;
        // Se asigna id de franquicia al objeto form que se enviara
        this.dataProdFranquicia.idFranquicia = newValue.idFranquicia;

        if (this.dataFranquicia.idFranquicia) {
          this.getProductosFranquicia();
        }
      },
    },
  },
  mounted() {
    // this.$refs.form.reset();
    //this.getProductos();
  },
  methods: {
    salirDialog() {
      // this.reset()
      this.$emit("close-form");
    },
    async getProductosFranquicia() {
      var self = this;
      self.isUpdate = false
      try {
        const res = await getListProductosFranquicia(
          self.dataFranquicia.idFranquicia
        );
        var its = res.data;
        self.listProdFranquicia = its;
      } catch (e) {
        this.errorMsj(e.toString())
      }
    },
    actualizar(item) {
      this.isUpdate = true;
      this.dataProdFranquicia = item;
      //this.idProd = item.idProducto;
    },
    async eliminar(item) {
      const response = await deleteProductosFranquicia(item.idFranquiciaProd);

      if (response.status === 204 || response.status === 200) {
        const index = this.listProdFranquicia.indexOf(item);
        this.listProdFranquicia.splice(index, 1);
      } else {
        this.errorMsj(response.status)
      }
    },
    errorMsj(msj) {
      this.$swal({
        title: "Error",
        text: msj,
        icon: "error",
        confirmButtonText: "Aceptar",
      });
    },
  },
};
</script>

<style lang="scss" scoped></style>
