<template>
  <div>
    <v-form
      ref="form"
      v-model="valid"
      lazy-validation
      @submit.prevent="guardar"
    >
      <v-card class="mx-auto" dark color="primary">
        <v-card-text>
          <v-row>
            <v-col cols="12">
              <v-autocomplete
                v-model="idProd"
                :items="items"
                color="blue-grey lighten-2"
                label="Seleccionar producto"
                item-text="producto"
                item-value="idProducto"
                cache-items
                flat
                hide-details
                @change="selectProducto()"
              >
                <template v-slot:no-data>
                  <v-list-item>
                    <v-list-item-title> Sin resultados </v-list-item-title>
                  </v-list-item>
                </template>
                <template v-slot:selection="{ attr, on, item, selected }">
                  <span v-text="item.producto" />
                  <v-list-item-subtitle v-text="item.categoria" />
                </template>
                <template v-slot:item="{ item }">
                  <v-list-item-content>
                    <v-list-item-title v-html="item.producto" />
                    <v-list-item-subtitle v-html="item.categoria" />
                  </v-list-item-content>
                </template>
              </v-autocomplete>
            </v-col>
            <v-col cols="12">
              <v-text-field
                v-model="dataProdFranquicia.precioVenta"
                :counter="15"
                :rules="[(v) => !!v || 'Precio reuerido']"
                label="Precio de venta"
                required
              />
            </v-col>
          </v-row>
        </v-card-text>
        <v-card-actions>
          <v-spacer />

          <v-btn color="error" small class="mr-2" @click="reset" dark>
            Cancelar
          </v-btn>
          <br />
          <v-btn
            v-if="!isUpdate"
            color="success"
            small
            class="mr-2"
            type="submit"
            dark
          >
            Guardar
          </v-btn>
          <v-btn v-else color="success" small class="mr-2" type="submit" dark>
            Actualizar
          </v-btn>
        </v-card-actions>
      </v-card>
    </v-form>
  </div>
</template>

<script>
import { getListProducto } from "@/api/productosApi";
import {
  postProductosFranquicia,
  putProductosFranquicia,
} from "@/api/franquiciasApi";

export default {
  name: "ProductoFranquiciaForm",
  props: {
    isUpdate: {
      type: Boolean,
      required: false,
      default: false,
    },
    idFranquicia: {
      type: Number,
      required: true
    },
    itemProducto:{
      type: Object,
      required: false,
      default: null,
    }
  },
  data() {
    return {
      valid: true,
      items: [],
      idProd: null,
      dataProdFranquicia: {
        idFranquiciaProd: 0,
        idFranquicia: 0,
        idProducto: 0,
        precioVenta: null,
      },
    };
  },
  watch: {
    itemProducto: {
        immediate: true,
        deep: true,
        handler(newValue, oldValue) {
          if (this.isUpdate) {
            this.dataProdFranquicia = newValue
            this.idProd = newValue.idProducto
          } else {
            this.dataProdFranquicia = {}
            this.dataProdFranquicia.idFranquicia = this.idFranquicia
            this.idProd = null
          }
        },
      },
  },
  mounted() {
    // this.$refs.form.reset();
    this.getProductos();
  },
  methods: {
    async getProductos() {
      try {
        const response = await getListProducto();
        this.items = response.data;
      } catch (e) {
        this.errorMsj(e.toString());
      }
    },
    selectProducto() {
      if (this.idProd) {
        this.dataProdFranquicia.idProducto = this.idProd;
      }
    },
    validarForm() {
      return this.$refs.form.validate();
    },
    async guardar() {
      if (this.validarForm()) {
        if (this.isUpdate) {
          const response = await putProductosFranquicia(
            this.dataProdFranquicia.idFranquiciaProd,
            this.dataProdFranquicia
          );
          if (response.status === 204) {
            this.reset();
                this.$emit('refresh-table')
            // this.$swal({
            //   title: "Actualizado correctamente",
            //   icon: "success",
            //   confirmButtonText: "Aceptar",
            // }).then((confirm) => {
            //   if (confirm) {
            //     this.reset();
            //     this.$emit('refresh-table')
            //   }
            // });
          } else {
            this.errorMsj(response.status);
          }
        } else {
          this.dataProdFranquicia.idFranquiciaProd = 0;
          const response = await postProductosFranquicia(
            this.dataProdFranquicia
          );

          if (response.status === 201 || response.status === 200) {
            this.reset();
                this.$emit('refresh-table')
            // this.$swal({
            //   title: "Agregado correctamente",
            //   icon: "success",
            //   confirmButtonText: "Aceptar",
            // }).then((confirm) => {
            //   if (confirm.isConfirmed) {

            //   }
            // });
          } else {
            this.errorMsj(response.status);
          }
        }
      }
    },
    reset() {
      this.$refs.form.reset();
      //this.$emit('reset-update');
    },
    errorMsj(msj) {
      this.$swal({
        title: "Error",
        text: msj,
        icon: "error",
        confirmButtonText: "Aceptar",
      });
    },
  },
};
</script>

<style lang="scss" scoped></style>
