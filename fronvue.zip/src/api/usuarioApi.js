﻿import { axiosSingleton } from '../plugins/axios'

const usuarios = "Usuarios"

//Login
export function getLogin(usr,pass) {
  return axiosSingleton.getInstance().get(`/${usuarios}/Login/${usr}/${pass}`)
}


