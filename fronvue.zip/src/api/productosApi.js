import { axiosSingleton } from '../plugins/axios'
const venta = "VentaProducto"
const producto = "Productos"
const prodInsumo = "ProductoInsumos"
const insumo = "Insumos"
const categoria = "Categorias"
const franquicia = "Franquicias"
const usuarios = "Usuarios"


//Usuarios
export function getListUsuarios() {
    return axiosSingleton.getInstance().get(`/${usuarios}`)
}
export function postUser(item) {
    return axiosSingleton.getInstance().post(`/${usuarios}`, item)
}

export function putUser(id, item) {
    return axiosSingleton.getInstance().put(`/${usuarios}/${id}`, item)
}

export function deleteUser(id) {
    return axiosSingleton.getInstance().delete(`/${usuarios}/${id}`)
}

//Roles
export function getListRol() {
    return axiosSingleton.getInstance().get(`/Rols`)
}

//Icons
export function getListIcons() {
    return axiosSingleton.getInstance().get(`/ImagenIcons`)
}

//Unidad de medida
export function getListUnidad() {
    return axiosSingleton.getInstance().get(`/UnidadMedidas`)
}

// Productos
export function getListProductoCategoria(idcat, idfra) {
    // var idcat=13;
    console.log("axios pd", idfra, idcat);
    return axiosSingleton.getInstance().get(`/${venta}/${idfra}/${idcat}`)
}
//Extras ppor categorias

export function getExtras(id) {
    // var idcat=13;
    console.log("axios id extras", id);
    return axiosSingleton.getInstance().get(`/${venta}/Extras/${id}`)
}

// cAtegoriaFRanquicia   api/VentaProducto/10
export function getLisCategoriaFranquicia(id) {
    return axiosSingleton.getInstance().get(`/${venta}/${id}`)
}


export function getListProducto() {
    return axiosSingleton.getInstance().get(`/${producto}`)
}

export function postProducto(item) {
    return axiosSingleton.getInstance().post(`/${producto}`, item)
}

export function putProducto(id, item) {
    return axiosSingleton.getInstance().put(`/${producto}/${id}`, item)
}

export function deleteProducto(id) {
    return axiosSingleton.getInstance().delete(`/${producto}/${id}`)
}

// Insumos
export function getListInsumo() {
    return axiosSingleton.getInstance().get(`/${insumo}`)
}

export function postInsumo(item) {
    return axiosSingleton.getInstance().post(`/${insumo}`, item)
}

export function putInsumo(id, item) {
    return axiosSingleton.getInstance().put(`/${insumo}/${id}`, item)
}

export function deleteInsumo(id) {
    return axiosSingleton.getInstance().delete(`/${insumo}/${id}`)
}

// Categorías
export function getListCategorias() {
    return axiosSingleton.getInstance().get(`/${categoria}`)
}

export function postCategoria(item) {
    return axiosSingleton.getInstance().post(`/${categoria}`, item)
}

export function putCategoria(id, item) {
    return axiosSingleton.getInstance().put(`/${categoria}/${id}`, item)
}

export function deleteCategoria(id) {
    return axiosSingleton.getInstance().delete(`/${categoria}/${id}`)
}

// Productos - Insumos
export function getListProdInsumo(id) {
    return axiosSingleton.getInstance().get(`/${prodInsumo}/${id}`)
}

export function postProdInsumo(item) {
    return axiosSingleton.getInstance().post(`/${prodInsumo}`, item)
}

export function putProdInsumo(id, item) {
    return axiosSingleton.getInstance().put(`/${prodInsumo}/${id}`, item)
}

export function deleteProdInsumo(id) {
    return axiosSingleton.getInstance().delete(`/${prodInsumo}/${id}`)
}
// farnquicias
export function getListFranquicias() {
    return axiosSingleton.getInstance().get(`/${franquicia}`)
}

export function postFranquicia(item) {
    return axiosSingleton.getInstance().post(`/${franquicia}`, item)
}

export function putFranquicia(id, item) {
    console.log("api", item)
    return axiosSingleton.getInstance().put(`/${franquicia}/${id}`, item)

}

export function deleteFranquicia(id) {
    return axiosSingleton.getInstance().delete(`/${franquicia}/${id}`)
}
