﻿import { axiosSingleton } from '../plugins/axios'

const franquicia = "Franquicias"
const producto = "FranquiciaProductos"
const stock = "Stocks"

// Farnquicias
export function getListFranquicias() {
    return axiosSingleton.getInstance().get(`/${franquicia}`)
}

export function postFranquicia(item) {
    return axiosSingleton.getInstance().post(`/${franquicia}`, item)
}

export function putFranquicia(id, item) {
    console.log("api", item)
    return axiosSingleton.getInstance().put(`/${franquicia}/${id}`, item)

}

export function deleteFranquicia(id) {
    return axiosSingleton.getInstance().delete(`/${franquicia}/${id}`)
}

// Productos - Franquicia
export function getListProductosFranquicia(id) {
    return axiosSingleton.getInstance().get(`/${producto}/Productos/${id}`)
}

export function postProductosFranquicia(item) {
    return axiosSingleton.getInstance().post(`/${producto}`, item)
}

export function putProductosFranquicia(id, item) {
    return axiosSingleton.getInstance().put(`/${producto}/${id}`, item)
}

export function deleteProductosFranquicia(id) {
    return axiosSingleton.getInstance().delete(`/${producto}/${id}`)
}

// Stock - Franquicia
export function getListStockFranquicia(id) {
    return axiosSingleton.getInstance().get(`/${stock}/Franquicia/${id}`)
}

export function postStockFranquicia(item) {
    return axiosSingleton.getInstance().post(`/${stock}`, item)
}

export function putStockFranquicia(id, item) {
    return axiosSingleton.getInstance().put(`/${stock}/${id}`, item)
}

export function deleteStockFranquicia(id) {
    return axiosSingleton.getInstance().delete(`/${stock}/${id}`)
}