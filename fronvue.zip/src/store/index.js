// Vue
import Vue from 'vue'
import Vuex from 'vuex'
 import axios from 'axios'
import pathify from '@/plugins/vuex-pathify'

// Modules
import * as modules from './modules'
import { axiosSingleton } from '../plugins/axios'

Vue.use(Vuex)

const store = new Vuex.Store({
  state: {
    status: '',
    token: localStorage.getItem('token') || '',
    user : {},
    Cuser:{},

},
mutations: {
  auth_request(state){
      state.status = 'loading'
    },
    auth_success(state, token, user){
      state.status = 'success'
      state.token = token
      state.user = user
    },
    auth_error(state){
      state.status = 'error'
    },
    logout(state){
      state.status = ''
      state.token = ''
    },
},
actions: {
    login({commit}, user){
        console.log ("login store" ,user);
        return new Promise((resolve, reject) => {
            commit('auth_request')
            // axios({url: `https://localhost:44305/api/Usuarios/Login/${user.email}/${user.password}`, method: 'POST' })
             axiosSingleton.getInstance().get(`/Usuarios/Login/${user.email}/${user.password}`)
            .then(resp => {
              // console.log ("login store" ,resp);
                const token = resp.data
                const user = resp.data.nombre
                console.log("token",token);
                console.log("user",user);
                // localStorage.setItem('token', token)
                localStorage.setItem('token', JSON.stringify(token));
                // localStorage.setItem('session', JSON.stringify(session));
                // Add the following line:
                axios.defaults.headers.common['Authorization'] = token
                commit('auth_success', token, user)
                resolve(resp)
                console.log ("salida del login ", resp);
            })
            .catch(err => {
              console.log("error");
                commit('auth_error')
                localStorage.removeItem('token')
                reject(err)
            })
        })
    },
    logout({commit}){
     
      return new Promise((resolve, reject) => {
          commit('logout')
          localStorage.removeItem('token')
          // console.log("cerrar session", 'token');
          delete axios.defaults.headers.common['Authorization']
          resolve()
      })
    }
},
getters : {
  isLoggedIn: state => !!state.token,
  authStatus: state => state.status,
},
  modules,
  plugins: [
    pathify.plugin,
  ],
})

store.subscribe(mutation => {
  if (!mutation.type.startsWith('user/')) return

  store.dispatch('user/update', mutation)
})

store.dispatch('app/init')

export default store

export const ROOT_DISPATCH = Object.freeze({ root: true })
