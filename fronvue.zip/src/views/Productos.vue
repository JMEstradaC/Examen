<template>
    <v-container fluid>
        <v-row>
            <v-col
                cols="12"
                md="12"
            >
                <material-card
                    color="accent"
                    full-header
                >
                    <template #heading>
                        <v-tabs
                            v-model="tabs"
                            background-color="transparent"
                            slider-color="white"
                            class="pa-8"
                        >
                            <v-tab class="mr-3">
                                <v-icon class="mr-2">
                                    mdi-ice-cream
                                </v-icon>
                                Productos
                            </v-tab>

                            <v-tab class="mr-3">
                                <v-icon class="mr-2">
                                    mdi-food-fork-drink
                                </v-icon>
                                Insumos
                            </v-tab>

                            <v-tab class="mr-3">
                                <v-icon class="mr-2">
                                    mdi-duck
                                </v-icon>
                                Categorías
                            </v-tab>
                        </v-tabs>
                    </template>
                    <v-tabs-items
                        v-model="tabs"
                        background-color="transparent"
                    >
                        <v-tab-item key="0">
                            <v-card-text>
                                <table-component
                                    title-table="Agregar producto"
                                    :headers="hProductos"
                                    :items-table="listProductos"
                                    :is-crud="true"
                                    :acctions-table="2"
                                    @open-form="agregarP"
                                    @item-edit="actualizarP"
                                    @item-delete="eliminarP"
                                    @consulta-relacionados="consultarP"
                                />
                            </v-card-text>
                        </v-tab-item>
                        <v-tab-item key="1">
                            <v-card-text>
                                <table-component
                                    title-table="Agregar insumo"
                                    :headers="hInsumos"
                                    :items-table="listInsumos"
                                    :is-crud="true"
                                    @open-form="agregarI"
                                    @item-edit="actualizarI"
                                    @item-delete="eliminarI"
                                />
                            </v-card-text>
                        </v-tab-item>
                        <v-tab-item key="2">
                            <v-card-text>
                                <table-component
                                    title-table="Agregar categoría"
                                    :headers="hCategoria"
                                    :items-table="listCategorias"
                                    :is-crud="true"
                                    @open-form="agregarC"
                                    @item-edit="actualizarC"
                                    @item-delete="eliminarC"
                                />
                            </v-card-text>
                        </v-tab-item>
                    </v-tabs-items>
                </material-card>
            </v-col>
        </v-row>
        <categoria-form
            :show-dialog="dialogC"
            :obj-categoria="itemCategoria"
            :is-update="isUpdateC"
            :categorias-registradas="listCategorias"
            @close-form="dialogC = false"
            @refresh-table="getCategorias"
        />
        <insumo-form
            :show-dialog="dialogI"
            :obj-insumo="itemInsumo"
            :is-update="isUpdateI"
            @close-form="dialogI = false"
            @refresh-table="getInsumos"
        />
        <producto-form
            :show-dialog="dialogP"
            :obj-producto="itemProducto"
            :is-update="isUpdateP"
            @close-form="dialogP = false"
            @refresh-table="getProductos"
        />

        <productos-insumos-crud
            :show-dialog="dialogProdIns"
            :obj-producto="itemProducto"
            @close-form="dialogProdIns = false"
        />
    </v-container>
</template>

<script>
  import TableComponent from '../components/generic/TableComponent.vue'
  import CategoriaForm from '../components/forms/CategoriaForm.vue'
  import InsumoForm from '../components/forms/InsumoProductoForm.vue'
  import ProductoForm from '../components/forms/ProductoForm.vue'
  import ProductosInsumosCrud from '../components/forms/ProductosInsumosCrud.vue'

  import {
    getListProducto,
    deleteProducto,
    getListInsumo,
    deleteInsumo,
    getListCategorias,
    deleteCategoria,
  } from '@/api/productosApi'

  export default {
    name: 'ProductosView',
    components: {
      TableComponent,
      CategoriaForm,
      InsumoForm,
      ProductoForm,
      ProductosInsumosCrud,
    },
    data() {
      return {
        tabs: 0,
        dialogC: false,
        dialogI: false,
        dialogP: false,
        dialogProdIns: false,
        isUpdateC: false,
        isUpdateI: false,
        isUpdateP: false,
        listProductos: [],
        listInsumos: [],
        listCategorias: [],
        itemProducto: {},
        itemInsumo: {},
        itemCategoria: {},
        hProductos: [
          {
            text: 'Código',
            value: 'codigoReferencia',
          },
          {
            text: 'Categoría',
            value: 'categoria',
          },
          {
            text: 'Nombre',
            value: 'producto',
          },
          {
            text: 'Extra',
            value: 'extra',
          },
          {
            text: 'Admin',
            value: 'acciones',
          },
        ],
        hInsumos: [
          {
            text: 'Código',
            value: 'codigoReferencia',
          },
          {
            text: 'Nombre',
            value: 'nombreInsumo',
          },
          {
            text: 'Medida',
            value: 'unidadMedida',
          },
          {
            text: 'Admin',
            value: 'acciones',
          },
        ],
        hCategoria: [
          {
            text: 'Nombre',
            value: 'nombre',
          },
          {
            text: 'Principal',
            value: 'catPadre',
          },
          {
            text: 'Extra',
            value: 'extra',
          },
          {
            text: 'Admin',
            value: 'acciones',
          },
        ],
      }
    },
    mounted() {
      this.getProductos()
      this.getInsumos()
      this.getCategorias()
    },
    methods: {
      async getProductos() {
        var self = this
        try {
          const response = await getListProducto()
          var items = response.data
          self.listProductos = items
        } catch (e) {
          console.log(e)
          this.$swal({
            title: 'Error',
            text: e.toString(),
            icon: 'error',
            confirmButtonText: 'Aceptar',
          })
        }
      },
      async getInsumos() {
        var self = this
        try {
          const res = await getListInsumo()
          var its = res.data
          self.listInsumos = its
        } catch (e) {
          console.log(e)
          this.$swal({
            title: 'Error',
            text: e.toString(),
            icon: 'error',
            confirmButtonText: 'Aceptar',
          })
        }
      },
      async getCategorias() {
        var self = this
        try {
          const resc = await getListCategorias()
          var itsc = resc.data

          self.listCategorias = itsc
        } catch (e) {
          this.$swal({
            title: 'Error',
            text: e.toString(),
            icon: 'error',
            confirmButtonText: 'Aceptar',
          })
        }
      },
      agregarP() {
        this.dialogP = true
        this.isConsultaP = false
        this.itemProducto = {}
      },
      consultarP(item) {
        this.dialogProdIns = true
        this.itemProducto = item
      },
      actualizarP(item) {
        this.dialogP = true
        this.isUpdateP = true
        this.itemProducto = item
      },
      async eliminarP(item) {
        const response = await deleteProducto(item.idProducto)

        if (response.status === 204 || response.status === 200) {
          const index = this.listProductos.indexOf(item)
          this.listProductos.splice(index, 1)
        } else {
          this.$swal({
            title: 'Error',
            text: response.status,
            icon: 'error',
            confirmButtonText: 'Aceptar',
          })
        }
      },
      agregarI() {
        this.dialogI = true
        this.itemInsumo = {}
      },
      consultarI(item) {
        this.dialogI = true
        this.itemInsumo = item
      },
      actualizarI(item) {
        this.dialogI = true
        this.isUpdateI = true
        this.itemInsumo = item
      },
      async eliminarI(item) {
        const response = await deleteInsumo(item.idInsumo)

        if (response.status === 204 || response.status === 200) {
          const index = this.listInsumos.indexOf(item)
          this.listInsumos.splice(index, 1)
        } else {
          this.$swal({
            title: 'Error',
            text: response.status,
            icon: 'error',
            confirmButtonText: 'Aceptar',
          })
        }
      },
      agregarC() {
        this.dialogC = true
        this.isConsultaC = false
        this.itemCategoria = {}
      },
      consultarC(item) {
        this.dialogC = true
        this.isConsultaC = true
        this.itemCategoria = item
      },
      actualizarC(item) {
        this.dialogC = true
        this.isUpdateC = true
        this.itemCategoria = item
      },
      async eliminarC(item) {
        const response = await deleteCategoria(item.idCategoria)

        if (response.status === 204 || response.status === 200) {
          const index = this.listCategorias.indexOf(item)
          this.listCategorias.splice(index, 1)
        } else {
          this.$swal({
            title: 'Error',
            text: response.status,
            icon: 'error',
            confirmButtonText: 'Aceptar',
          })
        }
      },
    },
  }
</script>

<style lang="scss" scoped></style>
