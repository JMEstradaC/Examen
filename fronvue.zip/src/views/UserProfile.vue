<template>
  <v-container id="user-profile-view" fluid tag="section">
    <v-row justify="center">
      <v-col cols="12" md="12">
        <template #title>
          Editar Pefil — <small class="text-body-1">Completa tu perfil</small>
        </template>

        <v-card-text>
          <table-component
            title-table="Agregar usuario"
            :headers="hProductos"
            :items-table="listUsuarios"
            :is-crud="true"
            :acctions-table="1"
            @open-form="agregarU"
            @item-edit="actualizarU"
            @item-delete="eliminarU"
            @item-insumos="consultarU"
          />
        </v-card-text>
      </v-col>
    </v-row>

    <v-row justify="center">
      <v-dialog
        v-model="dialog"
        persistent
        max-width="600px"
        color="transparent"
      >
        <v-col cols="12" md="12">
          <material-card color="primary" icon="mdi-account-outline">
            <template #title>
              Editar Pefil —
              <small class="text-body-1">Completa tu perfil</small>
            </template>

            <v-form
              ref="form"
              v-model="valid"
              lazy-validation
              @submit.prevent="guardar"
            >
              <v-container class="py-0">
                <v-row>
                  <v-col cols="12" md="6">
                    <v-text-field
                      v-model="dataUser.nombre"
                      :rules="[(v) => !!v || 'Nombre requerido']"
                      color="purple"
                      label="Nombres"
                    />
                  </v-col>
                  <v-col cols="12" md="6">
                    <v-text-field
                      v-model="dataUser.curp"
                      :rules="[(v) => !!v || 'CURP requerido']"
                      color="purple"
                      label="CURP"
                      @change="calcularEdadDesdeCURP()"
                    />
                  </v-col>
                  <v-col cols="12" md="2">
                    <v-text-field
                      v-model="dataUser.edad"
                      color="purple"
                      label="Edad"
                      type="number"
                      disabled
                    />
                  </v-col>
                  <v-col cols="12" md="6">
                    <v-text-field
                      v-model="dataUser.correo"
                      :rules="[(v) => !!v || 'Correo requerido']"
                      color="purple"
                      label="Correo electronico"
                    />
                  </v-col>
                  <v-col cols="12" md="4">
                    <v-text-field
                      v-model="dataUser.telefono"
                      :rules="[(v) => !!v || 'Telefono requerido']"
                      color="purple"
                      label="Telefono"
                      type="number"
                    />
                  </v-col>
                  <v-col cols="12" md="6">
                    <v-autocomplete
                      v-model="dataUser.pokemon"
                      :items="listPokes"
                      color="blue-grey lighten-2"
                      label="Seleccionar Pokemón Favorito"
                      item-text="name"
                      item-value="name"
                      cache-items
                      flat
                      hide-details
                    >
                      <template v-slot:no-data>
                        <v-list-item>
                          <v-list-item-title>
                            Sin resultados
                          </v-list-item-title>
                        </v-list-item>
                      </template>
                      <template v-slot:selection="{ attr, on, item, selected }">
                        <span v-text="item.name" />
                      </template>
                      <template v-slot:item="{ item }">
                        <v-list-item-content>
                          <v-list-item-title v-text="item.name" />
                        </v-list-item-content>
                      </template>
                    </v-autocomplete>
                  </v-col>
                  <v-col cols="12" md="4">
                    <v-file-input
                    v-model="file"
                    required
    show-size
    counter
    label="Foto"
  ></v-file-input>
                  </v-col>
                  <v-col cols="12" md="2">
                     <v-avatar v-if="dataUser.foto">
      <img
        :src="dataUser.foto"
        alt="User"
      >
    </v-avatar>
                  </v-col>
                  <v-col cols="12" md="6">
                    <v-autocomplete
                      v-model="dataUser.idFranquicia"
                      :items="ddlFranquicia"
                      color="blue-grey lighten-2"
                      label="Seleccionar Franquicia"
                      item-text="nombre"
                      item-value="idFranquicia"
                      cache-items
                      flat
                      hide-details
                    >
                      <template v-slot:no-data>
                        <v-list-item>
                          <v-list-item-title>
                            Sin resultados
                          </v-list-item-title>
                        </v-list-item>
                      </template>
                      <template v-slot:selection="{ attr, on, item, selected }">
                        <span v-text="item.nombre" />
                      </template>
                      <template v-slot:item="{ item }">
                        <v-list-item-content>
                          <v-list-item-title v-text="item.nombre" />
                        </v-list-item-content>
                      </template>
                    </v-autocomplete>
                  </v-col>
                  <v-col cols="12" md="6">
                    <v-autocomplete
                      v-model="dataUser.idRol"
                      :items="ddlRol"
                      color="blue-grey lighten-2"
                      label="Seleccionar Permiso"
                      item-text="nombre"
                      item-value="idRol"
                      cache-items
                      flat
                      hide-details
                    >
                      <template v-slot:no-data>
                        <v-list-item>
                          <v-list-item-title>
                            Sin resultados
                          </v-list-item-title>
                        </v-list-item>
                      </template>
                      <template v-slot:selection="{ attr, on, item, selected }">
                        <span v-text="item.nombre" />
                      </template>
                      <template v-slot:item="{ item }">
                        <v-list-item-content>
                          <v-list-item-title v-text="item.nombre" />
                        </v-list-item-content>
                      </template>
                    </v-autocomplete>
                  </v-col>
                  <v-col cols="6" class="text-right">
                    <v-btn color="success" type="submit" min-width="150">
                      Guardar
                    </v-btn>
                  </v-col>
                  <v-col cols="6" class="text-right">
                    <v-btn color="error" @click="salirDialog" min-width="150">
                      Cancelar
                    </v-btn>
                  </v-col>
                </v-row>
              </v-container>
            </v-form>
          </material-card>
        </v-col>
      </v-dialog>
    </v-row>
  </v-container>
</template>
<script>
import axios from 'axios'
import TableComponent from "../components/generic/TableComponent.vue";
import {
  getListFranquicias,
  getListRol,
  getListUsuarios,
  putUser,
  deleteUser,
  postUser,
} from "@/api/productosApi";
export default {
  name: "UserProfileView",
  components: { TableComponent },
    watch: {
    file: function (newVal, oldVal) {
      if(newVal) {
        this.createBase64Image(newVal);
      } else {
        // this.dataUser.foto = null;
      }
    }
  },
  data() {
    return {
      ddlFranquicia: [],
      ddlRol: [],
      valid: true,
      file:null,
      tabs: 0,
      dialog: false,
      dialogC: false,
      isUpdateC: false,
      listUsuarios: [],
      listInsumos: [],
      listPokes:[],
      itemUsuario: {},
      itemCategoria: {},
      dataUser: {
        idUsr: 0,
        idRol: 0,
        idFranquicia: 0,
        correo: "",
        nombre: "",
        telefono: 0,
        pass: "",
        curp: "",
        edad: 0,
        pokemon: "",
        foto:"",
        registro: new Date(),
      },
      hProductos: [
        {
          text: "ID",
          value: "idUsr",
        },
        {
          text: "Nombre",
          value: "nombre",
        },
        {
          text: "Correo",
          value: "correo",
        },
        {
          text: "Telefono",
          value: "telefono",
        },
        {
          text: "Franquicia",
          value: "idFranquicia",
        },
        {
          text: "Permisos",
          value: "idRol",
        },
        {
          text: "Acciones",
          value: "acciones",
        },
      ],
    };
  },
  mounted() {
    this.getFranquicia();
    this.getUsuarios();
    this.getRol();
    this.getPoket();
  },
  methods: {
    salirDialog() {
      this.isUpdate = false;
      this.dialog = false;
      this.dataUser = {};
    },
    async getRol() {
      var self = this;
      try {
        const res = await getListRol();
        this.ddlRol = res.data;
        // console.log("ddl ROl", this.ddlRol);
      } catch (e) {
        console.log(e);
      }
    },
    validarForm() {
      return this.$refs.form.validate();
    },
    async getPoket() {
      try {
      await axios
      .get('https://pokeapi.co/api/v2/pokemon?limit=1000&offset=1000')
      .then(response => (this.listPokes = response.data.results))

      console.log('Pokes',this.listPokes)
      } catch (e) {
        console.log('Error Pokes',e);
      }
    },
    async getFranquicia() {
      var self = this;
      try {
        const res = await getListFranquicias();

        this.ddlFranquicia = res.data;
        // console.log("getfranquicia", this.ddlFranquicia);
      } catch (e) {
        console.log(e);
      }
    },

    async getUsuarios() {
      var self = this;
      try {
        const response = await getListUsuarios();
        var iuser = response.data;
        self.listUsuarios = iuser;
      } catch (e) {
        console.log(e);
        this.$swal({
          title: "Error",
          text: e.toString(),
          icon: "error",
          confirmButtonText: "Aceptar",
        });
      }
    },

    async guardar() {
      if (this.validarForm()) {
        this.dataUser.registro = new Date();
        if (this.isUpdate) {
          let response = await putUser(this.dataUser.idUsr, this.dataUser);
          if (response.status === 204) {
            this.$swal({
              title: "Actualizado correctamente",
              icon: "success",
              confirmButtonText: "Aceptar",
            }).then((confirm) => {
              if (confirm) {
                this.getUsuarios();

                this.salirDialog();
              }
            });
          } else {
            this.$swal({
              title: "Error",
              text: response.status,
              icon: "error",
              confirmButtonText: "Aceptar",
            });
          }
        } else {
          console.log("Guardar", this.dataUser);
          let response = await postUser(this.dataUser);

          if (response.status === 201 || response.status === 200) {
            this.$swal({
              title: "Agregado correctamente",
              icon: "success",
              confirmButtonText: "Aceptar",
            }).then((confirm) => {
              if (confirm) {
                this.getUsuarios();
                this.salirDialog();
              }
            });
          } else {
            this.$swal({
              title: "Error",
              text: response.status,
              icon: "error",
              confirmButtonText: "Aceptar",
            });
          }
        }
      }
    },
    agregarU(item) {
      this.dialog = true;
      this.file = null;
    },
    consultarU(item) {
      this.dialog = true;
      this.dataUser = item;
    },
    actualizarU(item) {
      console.log("acualizar", item);
      this.dialog = true;
      this.isUpdate = true;
      this.dataUser = item;
      this.file = null;
    },
    async eliminarU(item) {
      const response = await deleteUser(item.idUsr);

      if (response.status === 204 || response.status === 200) {
        const index = this.listUsuarios.indexOf(item);
        this.listUsuarios.splice(index, 1);
      } else {
        this.$swal({
          title: "Error",
          text: response.status,
          icon: "error",
          confirmButtonText: "Aceptar",
        });
      }
    },
    createBase64Image: function(FileObject) {
      const reader = new FileReader();
      reader.onload = (event) => {
        this.dataUser.foto = event.target.result;
        console.log('foto',this.dataUser.foto)
      }
      reader.readAsDataURL(FileObject);
    },
    validarCURP(curp) {
        // Expresión regular para validar el formato general del CURP
      const regex =
        /^[A-Z]{4}[0-9]{6}[HM]{1}[A-Z]{2}[BCDFGHJKLMNPQRSTVWXYZ]{3}([A-Z]{2})?([0-9]{2})?$/;

      if (!regex.test(curp)) {
        return false; // Formato incorrecto
      }
      console.log('curp',curp)
      // Aquí se puede agregar la lógica para validar el dígito verificador
      // utilizando el algoritmo de cálculo del dígito verificador del CURP,
      // o consultando una API de validación.
      // Ejemplo de validación del dígito verificador (simplificado)
      const diccionario = "0123456789ABCDEFGHIJKLMNÑOPQRSTUVWXYZ";
      const curp17 = curp.substring(0, 17);
      let suma = 0;
      for (let i = 0; i < 17; i++) {
        suma += diccionario.indexOf(curp17[i]) * (18 - i);
      }
      const verificador = 10 - (suma % 10);
      if (verificador === 10) {
        if (curp.charAt(17) != "0") {
          return false;
        }
      } else if (curp.charAt(17) != verificador.toString()) {
        return false;
      }
      this.calcularEdadDesdeCURP();
      return true; // El CURP es válido
      // this.calcularEdadDesdeCURP();

    },
    calcularEdadDesdeCURP() {
      if(this.dataUser.curp.length >= 10){
      // Extraer la fecha de nacimiento del CURP (formato AAMMDD)
      const año = parseInt(this.dataUser.curp.substring(4, 6), 10);
      const mes = parseInt(this.dataUser.curp.substring(6, 8), 10) - 1; // Los meses en JavaScript son 0-indexados
      const dia = parseInt(this.dataUser.curp.substring(8, 10), 10);

      // Determinar el siglo (1900 o 2000)
      let siglo;
      if (año < new Date().getFullYear() % 100) {
        siglo = 2000;
      } else {
        siglo = 1900;
      }
      const fechaNacimiento = new Date(siglo + año, mes, dia);

      // Calcular la diferencia en años
      const hoy = new Date();
      this.dataUser.edad = hoy.getFullYear() - fechaNacimiento.getFullYear();
      const mesActual = hoy.getMonth();
      const diaActual = hoy.getDate();
      const mesNacimiento = fechaNacimiento.getMonth();
      const diaNacimiento = fechaNacimiento.getDate();

      if (
        mesActual < mesNacimiento ||
        (mesActual === mesNacimiento && diaActual < diaNacimiento)
      ) {
        this.dataUser.edad--;
      }

      // return edad;
      }
    },
  },
};
</script>
