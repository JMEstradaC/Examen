<template>
  <v-container id="franquicia-view" fluid tag="section">
    <v-row justify="center">
      <v-col cols="12" md="12">
        <material-card color="accent" icon="mdi-store">
          <template #title>
            Administrador de Franquicias
            <small class="text-body-1"> </small>
          </template>

          <v-card-text>
            <table-component title-table="Franquicias"
                             :headers="hFranquicias"
                             :items-table="listFranquicias"
                             :is-crud="true"
                             :acctions-table="3"
                             @consulta-relacionados="consultarP"
                             @consulta-stock="consultarI"
                             @open-form="agregarF"
                             @item-edit="actualizarF"
                             @item-delete="eliminarF" />
          </v-card-text>


        </material-card>
      </v-col>
    </v-row>
    <franquicia-form :show-dialog="dialogF"
                     :obj-categoria="itemFranquicia"
                     :is-update="isUpdateF"
                     @close-form="salirDialogF"
                     @refresh-table="getFranquicias" />

    <productos-franquicia-crud
      :show-dialog="dialogP"
      :obj-franquicia="itemFranquicia"
      @close-form="dialogP = false"
    />

    <insumo-franquicia-crud
      :show-dialog="dialogI"
      :obj-franquicia="itemFranquicia"
      @close-form="dialogI = false"
    />
  </v-container>
</template>


<script>
import TableComponent from "../components/generic/TableComponent.vue";
  import { getListFranquicias, deleteFranquicia} from "@/api/franquiciasApi";
import ProductosFranquiciaCrud from '../components/forms/ProductosFranquiciaCrud.vue';
import InsumoFranquiciaCrud from '../components/forms/InsumoFranquiciaCrud.vue';

export default {
  name: "FranquiciaView",
  components: {
    TableComponent,
    ProductosFranquiciaCrud,
    InsumoFranquiciaCrud,
  },
  data() {
    return {
      dialogF: false,
      isUpdateF: false,
      dialogP: false,
      dialogI: false,
      listFranquicias: [],
      itemFranquicia: {},
      hFranquicias: [
        {
          text: "ID",
          value: "idFranquicia",
        },
        {
          text: "Nombre",
          value: "nombre",
        },
        {
          text: "Ubicacion",
          value: "ubicación",
        },
        {
          text: "Correo",
          value: "correo",
        },
        {
          text: "Contaco Celular",
          value: "numeroCelular",
        },
        {
          text: "Acciones",
          value: "acciones",
        },
      ],

    };
  },
  mounted() {
    this.getFranquicias();
  },
  methods: {
    async getFranquicias() {
      var self = this;
      try {
        const res = await getListFranquicias();
        var its = res.data;
        self.listFranquicias = its;

      } catch (e) {
        this.$swal({
          title: "Error",
          text: e.toString(),
          icon: "error",
          confirmButtonText: "Aceptar",
        });

      }
    },
    agregarF() {
      this.dialogF = true;
      this.itemFranquicia = {};
    },
    actualizarF(item) {
      this.dialogF = true;
      this.isUpdateF = true;
      this.itemFranquicia = item;
    },
    async eliminarF(item) {

      const response = await deleteFranquicia(item.idFranquicia);

      if (response.status === 204 || response.status === 200) {
        const index = this.listFranquicias.indexOf(item);
        this.listFranquicias.splice(index, 1);
        this.$swal({
                  title: "Eliminado correctamente",
                  icon: "success",
                  confirmButtonText: "Aceptar",
                }).then((confirm) => {
                  if (confirm) {
                    this.getFranquicias();
                  }
                });
            } else {
              this.$swal({
                title: "Error",
                text: response.status,
                icon: "error",
                confirmButtonText: "Aceptar",
              });
    }
    },
    salirDialogF(show) {
      this.dialogF = show;
    },
    consultarP(item) {
        this.dialogP = true
        this.itemFranquicia = item
      },
    consultarI(item) {
        this.dialogI = true
        this.itemFranquicia = item
      },

  },
};
</script>

<style>
</style>
