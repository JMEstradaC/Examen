<template>
    <v-container
        id="Pedidos-View"
        fluid
    >
        <v-row>
            <v-col
                cols="12"
                md="6"
            >
                <material-card
                    color="#5DC1B9"
                    full-header
                >
                    <div>
                        <v-stepper v-model="e1">
                            <v-stepper-header
                                background-color="#5DC1B9"
                                slider-color="white"
                            >
                                <template v-for="n in steps">
                                    <v-stepper-step
                                        :key="`${n}-step`"
                                        :complete="e1 > n"
                                        :step="n"
                                        editable
                                    >
                                        Paso {{ n }}
                                    </v-stepper-step>

                                    <v-divider
                                        v-if="n !== steps"
                                        :key="n"
                                    />
                                </template>
                            </v-stepper-header>

                            <v-stepper-items>
                                <v-stepper-content
                                    v-for="n in steps"
                                    :key="`${n}-content`"
                                    :step="n"
                                >
                                    <check-list
                                        :items-list="listSabores"
                                        @item-asign="asignarB"
                                    />

                                    <v-btn
                                        color="primary"
                                        @click="nextStep(n)"
                                    >
                                        Continuar
                                    </v-btn>

                                    <v-btn text>
                                        Cancelar
                                    </v-btn>

                                    <v-btn
                                        v-if="Extra == true"
                                        explore
                                        color="secondary"
                                        style="float: right;"
                                        @click="ExtraA"
                                    >
                                        Extra
                                    </v-btn>
                                </v-stepper-content>
                            </v-stepper-items>
                        </v-stepper>
                    </div>
                    <!-- Listado de categorias de productos -->
                    <template #heading>
                        <v-bottom-navigation
                            v-model="value"
                            :background-color="color"
                            dark
                            shift
                        >
                            <v-btn
                                v-for="(item, index) of listCategorias"
                                :key="index"
                                @click="asignarA(item)"
                            >
                                <span>{{ item.categoria }}</span>
                                <v-icon class="mr-2">
                                    mdi-{{item.icon}}
                                </v-icon>
                            </v-btn>
                        </v-bottom-navigation>
                    </template>
                </material-card>
            </v-col>
            <!-- Pedido seleccionado -->
            <v-col
                cols="12"
                md="6"
            >
                <v-card-title class="indigo white--text text-h5">
                    User Directory Empleado
                </v-card-title>
                <material-card
                    color="#5DC1B9"
                    full-header
                >
                    <v-container>
                        <v-row>
                            <v-divider vertical />
                            <v-col
                                class="pa-6"
                                cols="6"
                            >
                                <template v-if="!itemCategoriaSel.length">
                                    No nodes selected.
                                </template>
                                <template v-else>
                                    <div
                                        v-for="node in itemCategoriaSel"
                                        :key="node.id"
                                    >
                                        {{ node.nombre }}
                                    </div>
                                </template>
                            </v-col>
                        </v-row>
                    </v-container>
                </material-card>
            </v-col>
        </v-row>
    </v-container>
</template>

<script>
// Utilities
  import CheckList from '../components/generic/CheckList.vue'
  import {
    getExtras,
    deleteProducto,
    getLisCategoriaFranquicia,
    getListProductoCategoria,
  } from '@/api/productosApi'

  export default {
    name: 'PedidosView',
    components: {
      CheckList,
    },

    data: () => ({
      rese: [],
      listExtras: [],
      Extra: false,
      idFranquicia: 0,
      value: 0,
      e1: 1,
      steps: 1,
      item: [],
      itemCategoriaSel: [],
      tabs: 0,
      items: [],
      listCategorias: [],
      listSabores: [],
      model: ['Carrots'],
      tasks: {},
      selectionType: 'leaf',
      selection: [],
    }),
    computed: {
      color() {
        switch (this.value) {
          case 0:
            return 'blue'
          case 1:
            return 'teal'
          case 2:
            return 'indigo'
          case 3:
            return 'brown'
          case 4:
            return 'green'
          default:
            return 'blue-grey'
        }
      },
    },
    watch: {
      steps(val) {
        if (this.e1 > val) {
          this.e1 = val
        }
      },
    },

    mounted() {
      this.getProductos()
    },
    methods: {
      modalitem(item) {
        console.log('valor de items en modal', item)
      },

      nextStep(n) {
        if (n === this.steps) {
          this.e1 = 1
        } else {
          this.e1 = n + 1
        }
      },

      async getProductos() {
        const obj = JSON.parse(localStorage.getItem('token'))
        this.idFranquicia = obj.idFranquicia
        console.log('intentado sacar', this.idFranquicia)
        try {
          const resc = await getLisCategoriaFranquicia(this.idFranquicia)
          this.listCategorias = resc.data

          console.log('categorias', this.listCategorias)
        } catch (e) {
          console.log(e)
        // this.tipoMsj = 2;
        // this.msjDialog = "Error";
        }
      },

      asignar(item) {
        console.log('Item paso 2', item)
      },

      asignarA(item) {
        console.log('Item paso 2', item)

        if (item.subCategorias != null) {
          this.steps = 4
          this.listSabores = item.subCategorias
          console.log('si teien sub', this.listSabores)
        } else {
          this.listSabores = []
          console.log('NO teien sub')
        }
      },

      async ExtraA() {
        console.log('extra', this.idFranquicia)

        const res = await getExtras(this.idFranquicia)
        var rese = res
        console.log('estras res', rese)
        this.listExtras = res
      },

      asignarB(item) {
        console.log('cargar producto y franquicia B', item)
        this.idCatExtra = item.id_Categoria
        this.Extra = item.aplicaExtra
        var respuesta = getListProductoCategoria(
          item.id_Categoria,
          this.idFranquicia
        )
        respuesta.then(function(v) {
          this.listSabores = v.data
        //  console.log("list producto categoria",this.listSabores);
        })
        console.log('asign B', this.listSabores)
      },
    },
  }
</script>
