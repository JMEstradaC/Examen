<template>
  <v-app id="login" class="institut">
    <v-main>
      <v-container fluid fill-height>
        <v-layout align-center justify-center>
          <v-flex xs12 sm8 md4 lg4>
            <v-card class="elevation-1 pa-3">
              <v-card-text>
                <div class="layout column align-center">

                  <img  src="@/assets/elate.png" alt="Vue Material Admin" width="180" height="180">
                  <h1 class="flex my-4 primary--text">ELATE</h1>
                </div>
                <v-form>
                  <v-text-field
                    append-icon="mdi-account"
                    name="login"
                    label="Usuario"
                    type="text"
                    v-model="userEmail"
                    :error="error"
                    :rules="[rules.required]"/>
                  <v-text-field
                    :type="hidePassword ? 'password' : 'text'"
                    :append-icon="hidePassword ? 'mdi-eye-off' : 'mdi-eye'"
                    name="password"
                    label="Contraseña"
                    id="password"
                    :rules="[rules.required]"
                    v-model="password"
                    :error="error"
                    @click:append="hidePassword = !hidePassword"/>
                </v-form>
              </v-card-text>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn block color="primary" @click="login" :loading="loading">Login</v-btn>
              </v-card-actions>
            </v-card>
          </v-flex>
        </v-layout>
      </v-container>
       <contrasena-form
      :show-dialog="dialogF"
      :obj-usuario="itemChange"
      @close-form="salirDialogF"
    />
      <v-snackbar
        v-model="showResult"
        :timeout="2000"
        top>
        {{ result }}
      </v-snackbar>
    </v-main>
  </v-app>
</template>

<script>
  export default {
    name: 'LoginView',
     components: {

    },
  data() {
    return {
      itemChange: {},
      dialogF: false,
      serStatus:0,
      loading: false,
      userEmail: '',
      password: '',
      hidePassword: true,
      error: false,
      showResult: false,
      result: '',
      rules: {
        required: value => !!value || 'Datos necesarios.'
      }
    }
  },

  methods: {
      salirDialogF(show) {
      this.dialogF = show;
      this.password="";
    },
    login() {
      const vm = this;
      if (!vm.userEmail || !vm.password) {
        vm.result = "usuario y pasword son requeridos.";
        vm.showResult = true;
        return;
      }
      var email=vm.userEmail;
      var password=vm.password;

       let resultado= this.$store.dispatch('login', { email, password })
      // .then((res) =>console.log("res",res.status))
      .then(respuesta => { 
        console.log("respuesta", respuesta.data);
        if(respuesta.data.nombre=="change"){
      
      this.itemChange=respuesta.data;
        console.log("change", this.itemChange);
      this.dialogF = true;
      this.isConsultaI = false;   
      }
      else if(respuesta.status==200) {
          console.log("es true");
        vm.$router.push({ name: 'Dashboard' });
      } 
      else {
        vm.error = true;
        vm.result = "Datos incorrectos.";
        vm.showResult = true;
      }})
      // .then((res) => this.serStatus= res.status)
      .catch((error) => console.log("errores",error));
    }
  }
}
</script>

<style scoped lang="css">
  #login {
    height: 50%;
    width: 100%;
    position: absolute;
    top: 0;
    left: 0;
    content: "";
    z-index: 0;
  }

  .institut {
    background-color: #5DC1B9;
  }
</style>
